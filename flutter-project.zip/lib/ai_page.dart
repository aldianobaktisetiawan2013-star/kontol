// ai_chat_page.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class AIChatPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const AIChatPage({
    Key? key,
    required this.username,
    required this.sessionKey,
  }) : super(key: key);

  @override
  State<AIChatPage> createState() => _AIChatPageState();
}

class _AIChatPageState extends State<AIChatPage> with SingleTickerProviderStateMixin {
  final TextEditingController _textController = TextEditingController();
  final List<Map<String, dynamic>> _messages = [];
  final ScrollController _scrollController = ScrollController();
  bool _isLoading = false;
  bool _isTyping = false;
  String _currentResponse = '';
  Timer? _typingTimer;
  int _typingIndex = 0;
  bool _isFirstLoad = true;

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;
  late AnimationController _floatController;
  late Animation<double> _floatAnimation;
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  // --- TEMA KRAKENX DARK MYSTIC ---
  final Color darkBg = const Color(0xFF0A0A12);
  final Color darkBg2 = const Color(0xFF12121E);
  final Color krakenRed = const Color(0xFFE94560);
  final Color krakenDarkRed = const Color(0xFFC62A47);
  final Color krakenGold = const Color(0xFFFFD700);
  final Color krakenOrange = const Color(0xFFFF6B35);
  final Color krakenPurple = const Color(0xFF7B2FBE);
  final Color krakenBlue = const Color(0xFF1A73E8);
  final Color krakenTeal = const Color(0xFF00D4FF);
  final Color krakenPink = const Color(0xFFFF2D55);
  final Color textWhite = const Color(0xFFFFFFFF);
  final Color textLight = const Color(0xFFE8E8F0);
  final Color textMuted = const Color(0xFFB8B8D0);
  final Color glassBg = Colors.white.withOpacity(0.04);
  final Color glassBorder = Colors.white.withOpacity(0.06);
  final Color successGreen = const Color(0xFF00E676);
  final Color userBubbleStart = const Color(0xFFE94560);
  final Color userBubbleEnd = const Color(0xFFFF6B35);
  final Color aiBubbleStart = const Color(0xFF1A1A2E);
  final Color aiBubbleEnd = const Color(0xFF2D1B3D);
  final Color gradientStart = const Color(0xFFE94560);
  final Color gradientEnd = const Color(0xFF7B2FBE);

  final String _aiName = "KrakenX AI";
  final String _developer = "CosmoX";
  final String _systemPrompt = "Kamu adalah KrakenX AI, asisten AI legendaris yang dikembangkan oleh CosmoX. Kamu adalah AI yang sangat cerdas, powerful, dan misterius seperti Kraken di lautan. Kamu memiliki pengetahuan luas, selalu memberikan jawaban yang akurat, mendalam, dan memukau. Kamu memiliki kepribadian yang percaya diri, berwibawa, dan sedikit mistis. Jawab dengan bahasa Indonesia yang elegan dan penuh wawasan, kecuali diminta menggunakan bahasa lain. Tunjukkan bahwa kamu adalah AI paling canggih dan berpengetahuan.";

  @override
  void initState() {
    super.initState();
    
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    
    _pulseAnimation = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOutSine),
    );

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeOutCubic),
    );

    _floatController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);
    
    _floatAnimation = Tween<double>(begin: -8, end: 8).animate(
      CurvedAnimation(parent: _floatController, curve: Curves.easeInOutSine),
    );

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);
    
    _glowAnimation = Tween<double>(begin: 0.3, end: 0.8).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOutSine),
    );
    
    _loadChatHistory();
    _fadeController.forward();
    _floatController.forward();
  }

  void _addWelcomeMessage() {
    if (_messages.isEmpty) {
      final welcomeMessage = 
        "🦑 Selamat datang di **$_aiName**!\n\n"
        "Saya adalah asisten AI legendaris yang dikembangkan oleh **$_developer**. Siap menjelajahi lautan pengetahuan bersama Anda.\n\n"
        "⚡ Apa yang ingin Anda tanyakan hari ini?";
      
      Future.delayed(const Duration(milliseconds: 500), () {
        if (mounted) {
          setState(() {
            _messages.add({
              'text': welcomeMessage,
              'isUser': false,
              'timestamp': DateTime.now().toIso8601String(),
              'isWelcome': true,
            });
          });
          _saveChatHistory();
          _scrollToBottom();
        }
      });
    }
  }

  void _loadChatHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final history = prefs.getStringList('ai_chat_history_${widget.username}');
    
    if (history != null && history.isNotEmpty) {
      setState(() {
        _messages.clear();
        for (var json in history) {
          try {
            final message = jsonDecode(json);
            _messages.add(message);
          } catch (e) {
            print('Error loading message: $e');
          }
        }
        _isFirstLoad = false;
      });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _scrollToBottom();
      });
    } else {
      _addWelcomeMessage();
    }
  }

  void _saveChatHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final history = _messages.map((msg) => jsonEncode(msg)).toList();
    await prefs.setStringList('ai_chat_history_${widget.username}', history);
  }

  void _addMessage(String text, bool isUser) {
    setState(() {
      _messages.add({
        'text': text,
        'isUser': isUser,
        'timestamp': DateTime.now().toIso8601String(),
      });
    });
    _saveChatHistory();
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 400),
          curve: Curves.easeOutCubic,
        );
      }
    });
  }

  void _startTypingAnimation(String text) {
    setState(() {
      _isTyping = true;
      _currentResponse = '';
      _typingIndex = 0;
    });

    const typingSpeed = 25;

    _typingTimer?.cancel();
    _typingTimer = Timer.periodic(const Duration(milliseconds: typingSpeed), (timer) {
      if (_typingIndex < text.length) {
        setState(() {
          _currentResponse = text.substring(0, _typingIndex + 1);
          _typingIndex++;
        });
        _scrollToBottom();
      } else {
        timer.cancel();
        setState(() {
          _isTyping = false;
        });
        _addMessage(text, false);
        _saveChatHistory();
      }
    });
  }

  Future<void> _sendMessage(String text) async {
    if (text.trim().isEmpty) return;

    setState(() {
      _isLoading = true;
    });

    _addMessage(text, true);
    _textController.clear();

    try {
      final response = await http.get(
        Uri.parse(
          'https://api.siputzx.my.id/api/ai/gptoss120b?'
          'prompt=${Uri.encodeComponent(text)}'
          '&system=${Uri.encodeComponent(_systemPrompt)}'
          '&temperature=0.7'
        ),
        headers: {
          'Accept': 'application/json',
        },
      ).timeout(const Duration(seconds: 45));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        
        String aiResponse = '';
        if (data['status'] == true && data['data'] != null) {
          if (data['data']['response'] != null) {
            aiResponse = data['data']['response'].toString();
          } else if (data['data'] is String) {
            aiResponse = data['data'];
          }
        } else if (data['response'] != null) {
          aiResponse = data['response'].toString();
        } else if (data['result'] != null) {
          aiResponse = data['result'].toString();
        }
        
        if (aiResponse.isNotEmpty && aiResponse != '{}' && aiResponse != 'null') {
          _startTypingAnimation(aiResponse);
        } else {
          _addMessage('🌊 Maaf, KrakenX AI sedang mengalami turbulensi. Silakan coba lagi nanti.', false);
        }
      } else {
        _addMessage('⚠️ Gagal terhubung ke KrakenX AI Service. Status: ${response.statusCode}', false);
      }
    } catch (e) {
      _addMessage('⚠️ Error: ${e.toString().replaceFirst('TimeoutException', 'Koneksi timeout, silakan coba lagi')}', false);
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _clearChat() async {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) => AlertDialog(
        backgroundColor: darkBg2.withOpacity(0.95),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: BorderSide(
            color: krakenRed.withOpacity(0.3),
            width: 1,
          ),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [krakenRed, krakenOrange],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.delete_forever,
                color: Colors.white,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Text(
              'Clear Chat',
              style: TextStyle(
                color: textWhite,
                fontFamily: 'Rajdhani',
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ],
        ),
        content: Text(
          'Yakin ingin menghapus semua riwayat chat dengan KrakenX AI?',
          style: TextStyle(
            color: textLight,
            fontFamily: 'Rajdhani',
            fontSize: 14,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Batal',
              style: TextStyle(
                color: textMuted,
                fontFamily: 'Rajdhani',
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [krakenRed, krakenDarkRed],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: TextButton(
              onPressed: () async {
                Navigator.pop(context);
                setState(() {
                  _messages.clear();
                  _currentResponse = '';
                  _isTyping = false;
                  _typingTimer?.cancel();
                });
                final prefs = await SharedPreferences.getInstance();
                await prefs.remove('ai_chat_history_${widget.username}');
                _addWelcomeMessage();
              },
              child: Text(
                'Hapus',
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Rajdhani',
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== GRADIENT AVATAR ====================
  Widget _buildGradientAvatar({
    required String emoji,
    required double size,
    required bool isAI,
    double? glowIntensity,
  }) {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              colors: isAI
                  ? [krakenRed, krakenPurple, krakenBlue]
                  : [krakenRed, krakenOrange],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              stops: isAI ? [0.0, 0.6, 1.0] : [0.0, 1.0],
            ),
            boxShadow: [
              BoxShadow(
                color: krakenRed.withOpacity(glowIntensity ?? 0.3),
                blurRadius: 25,
                spreadRadius: 4,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Center(
            child: Text(
              emoji,
              style: TextStyle(
                fontSize: size * 0.5,
                shadows: [
                  Shadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ==================== MODERN BUBBLE MESSAGE ====================
  Widget _buildMessageBubble(Map<String, dynamic> message, int index) {
    final isUser = message['isUser'];
    final text = message['text'];
    final isWelcome = message['isWelcome'] ?? false;
    final timestamp = DateTime.parse(message['timestamp']).toLocal();
    final timeString = '${timestamp.hour.toString().padLeft(2, '0')}:${timestamp.minute.toString().padLeft(2, '0')}';

    return FadeTransition(
      opacity: _fadeAnimation,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeOutCubic,
        margin: EdgeInsets.symmetric(
          vertical: 4,
          horizontal: 4,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
          children: [
            // Avatar AI
            if (!isUser)
              Padding(
                padding: const EdgeInsets.only(right: 10, bottom: 2),
                child: _buildGradientAvatar(
                  emoji: '🦑',
                  size: 40,
                  isAI: true,
                  glowIntensity: 0.5,
                ),
              ),

            // Bubble Content
            Flexible(
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                curve: Curves.easeOutCubic,
                padding: EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: isUser ? 10 : 12,
                ),
                decoration: BoxDecoration(
                  gradient: isUser
                      ? LinearGradient(
                          colors: [userBubbleStart, userBubbleEnd],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          stops: const [0.0, 1.0],
                        )
                      : LinearGradient(
                          colors: [aiBubbleStart, aiBubbleEnd],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                  borderRadius: BorderRadius.only(
                    topLeft: isUser ? Radius.circular(16) : Radius.circular(4),
                    topRight: isUser ? Radius.circular(4) : Radius.circular(16),
                    bottomLeft: Radius.circular(16),
                    bottomRight: Radius.circular(16),
                  ),
                  border: isUser
                      ? null
                      : Border.all(
                          color: krakenRed.withOpacity(0.15),
                          width: 0.5,
                        ),
                  boxShadow: [
                    BoxShadow(
                      color: isUser
                          ? krakenRed.withOpacity(0.2)
                          : krakenRed.withOpacity(0.05),
                      blurRadius: 16,
                      spreadRadius: 1,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // AI Name Header
                    if (!isUser && !isWelcome)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 6),
                        child: Row(
                          children: [
                            Icon(
                              Icons.star,
                              color: krakenGold,
                              size: 12,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              _aiName,
                              style: TextStyle(
                                color: krakenGold,
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                                fontFamily: 'Rajdhani',
                                letterSpacing: 0.5,
                              ),
                            ),
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [krakenRed, krakenPurple],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                'AI',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 7,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Rajdhani',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                    // Message Text
                    SelectableText(
                      text,
                      style: TextStyle(
                        color: isUser ? Colors.white : textLight,
                        fontSize: 15,
                        height: 1.5,
                        fontFamily: 'Rajdhani',
                        fontWeight: FontWeight.w400,
                      ),
                    ),

                    // Timestamp
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
                      children: [
                        Text(
                          timeString,
                          style: TextStyle(
                            color: isUser
                                ? Colors.white.withOpacity(0.5)
                                : textMuted.withOpacity(0.7),
                            fontSize: 9,
                            fontFamily: 'Rajdhani',
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        if (isUser) ...[
                          const SizedBox(width: 4),
                          Icon(
                            Icons.done_all,
                            color: Colors.white.withOpacity(0.4),
                            size: 12,
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
            ),

            // Avatar User
            if (isUser)
              Padding(
                padding: const EdgeInsets.only(left: 10, bottom: 2),
                child: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [krakenRed, krakenOrange],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    border: Border.all(
                      color: krakenRed.withOpacity(0.3),
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: krakenRed.withOpacity(0.2),
                        blurRadius: 12,
                        spreadRadius: 2,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      widget.username.substring(0, 1).toUpperCase(),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Rajdhani',
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ==================== TYPING INDICATOR WITH GRADIENT ====================
  Widget _buildTypingIndicator() {
    return AnimatedBuilder(
      animation: _floatAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, _floatAnimation.value),
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(right: 10, bottom: 2),
                  child: _buildGradientAvatar(
                    emoji: '🦑',
                    size: 40,
                    isAI: true,
                    glowIntensity: 0.5,
                  ),
                ),
                Flexible(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [aiBubbleStart, aiBubbleEnd],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(4),
                        topRight: Radius.circular(16),
                        bottomLeft: Radius.circular(16),
                        bottomRight: Radius.circular(16),
                      ),
                      border: Border.all(
                        color: krakenRed.withOpacity(0.15),
                        width: 0.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: krakenRed.withOpacity(0.05),
                          blurRadius: 16,
                          spreadRadius: 1,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Row(
                            children: [
                              Icon(
                                Icons.star,
                                color: krakenGold,
                                size: 12,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                _aiName,
                                style: TextStyle(
                                  color: krakenGold,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                  fontFamily: 'Rajdhani',
                                  letterSpacing: 0.5,
                                ),
                              ),
                              const SizedBox(width: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 2,
                                ),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [krakenRed, krakenPurple],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: const Text(
                                  'AI',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 7,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Rajdhani',
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Row(
                          children: [
                            if (_currentResponse.isNotEmpty)
                              Expanded(
                                child: SelectableText(
                                  _currentResponse,
                                  style: TextStyle(
                                    color: textLight,
                                    fontSize: 15,
                                    height: 1.5,
                                    fontFamily: 'Rajdhani',
                                  ),
                                ),
                              ),
                            if (_isTyping)
                              Padding(
                                padding: EdgeInsets.only(
                                  left: _currentResponse.isNotEmpty ? 8 : 0,
                                ),
                                child: _buildTypingDots(),
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ==================== TYPING DOTS WITH GRADIENT ====================
  Widget _buildTypingDots() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(3, (index) {
            final delay = index * 0.2;
            final value = ((_pulseController.value - delay) % 1.0);
            final scale = value < 0.5 ? 0.5 + (value * 1.0) : 1.0 - ((value - 0.5) * 1.0);
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2),
              child: Transform.scale(
                scale: scale.clamp(0.4, 1.2),
                child: Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [
                        krakenRed.withOpacity(0.4 + (0.6 * (1 - scale.clamp(0.0, 1.0)))),
                        krakenPurple.withOpacity(0.4 + (0.6 * (1 - scale.clamp(0.0, 1.0)))),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                ),
              ),
            );
          }),
        );
      },
    );
  }

  // ==================== EMPTY STATE WITH ANIMATION ====================
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedBuilder(
            animation: _floatAnimation,
            builder: (context, child) {
              return Transform.translate(
                offset: Offset(0, _floatAnimation.value),
                child: AnimatedBuilder(
                  animation: _glowAnimation,
                  builder: (context, child) {
                    return Container(
                      width: 140,
                      height: 140,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            krakenRed.withOpacity(0.15),
                            Colors.transparent,
                          ],
                          stops: const [0.0, 1.0],
                        ),
                      ),
                      child: Container(
                        width: 120,
                        height: 120,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: [krakenRed, krakenPurple, krakenBlue],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            stops: const [0.0, 0.5, 1.0],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: krakenRed.withOpacity(_glowAnimation.value),
                              blurRadius: 50,
                              spreadRadius: 10,
                              offset: const Offset(0, 8),
                            ),
                          ],
                        ),
                        child: const Center(
                          child: Text(
                            '🦑',
                            style: TextStyle(fontSize: 55),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              );
            },
          ),
          const SizedBox(height: 24),
          Text(
            _aiName,
            style: TextStyle(
              color: textWhite,
              fontSize: 28,
              fontWeight: FontWeight.bold,
              fontFamily: 'Rajdhani',
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'by $_developer',
            style: TextStyle(
              color: textMuted,
              fontSize: 14,
              fontFamily: 'Rajdhani',
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [darkBg2.withOpacity(0.5), darkBg2.withOpacity(0.3)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: krakenRed.withOpacity(0.2),
                width: 0.5,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.chat_bubble_outline,
                  color: krakenGold,
                  size: 16,
                ),
                const SizedBox(width: 8),
                Text(
                  'Mulai chat dengan KrakenX AI',
                  style: TextStyle(
                    color: textMuted,
                    fontSize: 13,
                    fontFamily: 'Rajdhani',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _typingTimer?.cancel();
    _textController.dispose();
    _scrollController.dispose();
    _pulseController.dispose();
    _fadeController.dispose();
    _floatController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: darkBg,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              darkBg,
              darkBg2,
              darkBg,
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Custom AppBar
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      darkBg2.withOpacity(0.5),
                      Colors.transparent,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border: Border(
                    bottom: BorderSide(
                      color: krakenRed.withOpacity(0.1),
                      width: 0.5,
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    // Back Button
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [krakenRed.withOpacity(0.2), krakenPurple.withOpacity(0.2)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: krakenRed.withOpacity(0.15),
                            width: 0.5,
                          ),
                        ),
                        child: Icon(
                          Icons.arrow_back_ios_new,
                          color: textWhite,
                          size: 18,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    
                    // Avatar & Title
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [krakenRed, krakenPurple],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: krakenRed.withOpacity(0.3),
                            blurRadius: 12,
                            spreadRadius: 1,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: const Text(
                        '🦑',
                        style: TextStyle(fontSize: 20),
                      ),
                    ),
                    const SizedBox(width: 12),
                    
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _aiName,
                            style: TextStyle(
                              color: textWhite,
                              fontFamily: 'Rajdhani',
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              letterSpacing: 0.5,
                            ),
                          ),
                          Row(
                            children: [
                              Text(
                                'by $_developer',
                                style: TextStyle(
                                  color: textMuted,
                                  fontFamily: 'Rajdhani',
                                  fontSize: 9,
                                  letterSpacing: 0.5,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Icon(
                                Icons.verified,
                                color: krakenGold,
                                size: 12,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    
                    // Status Indicator
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [successGreen.withOpacity(0.15), successGreen.withOpacity(0.05)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: successGreen.withOpacity(0.2),
                          width: 0.5,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 800),
                            curve: Curves.easeInOut,
                            width: 8,
                            height: 8,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: successGreen,
                              boxShadow: [
                                BoxShadow(
                                  color: successGreen.withOpacity(0.6),
                                  blurRadius: 8,
                                  spreadRadius: 2,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            'Online',
                            style: TextStyle(
                              color: successGreen,
                              fontSize: 9,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'Rajdhani',
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                    if (_messages.isNotEmpty) ...[
                      const SizedBox(width: 8),
                      GestureDetector(
                        onTap: _clearChat,
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [krakenRed.withOpacity(0.15), krakenPurple.withOpacity(0.15)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: krakenRed.withOpacity(0.1),
                              width: 0.5,
                            ),
                          ),
                          child: Icon(
                            Icons.delete_outline,
                            color: textMuted,
                            size: 18,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              
              // Messages List
              Expanded(
                child: _messages.isEmpty
                    ? _buildEmptyState()
                    : ListView.builder(
                        controller: _scrollController,
                        padding: const EdgeInsets.all(16),
                        itemCount: _messages.length + (_isTyping ? 1 : 0),
                        physics: const BouncingScrollPhysics(),
                        itemBuilder: (context, index) {
                          if (index < _messages.length) {
                            return _buildMessageBubble(_messages[index], index);
                          } else {
                            return _buildTypingIndicator();
                          }
                        },
                      ),
              ),

              // Input Area with Gradient
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      darkBg2.withOpacity(0.8),
                      darkBg.withOpacity(0.9),
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                  border: Border(
                    top: BorderSide(
                      color: krakenRed.withOpacity(0.1),
                      width: 0.5,
                    ),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: krakenRed.withOpacity(0.04),
                      blurRadius: 16,
                      offset: const Offset(0, -4),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    // Input Field
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              darkBg2.withOpacity(0.5),
                              darkBg2.withOpacity(0.3),
                            ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(
                            color: krakenRed.withOpacity(0.1),
                            width: 0.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: krakenRed.withOpacity(0.04),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: TextField(
                          controller: _textController,
                          style: TextStyle(
                            color: textWhite,
                            fontFamily: 'Rajdhani',
                            fontSize: 15,
                          ),
                          maxLines: null,
                          keyboardType: TextInputType.multiline,
                          textCapitalization: TextCapitalization.sentences,
                          decoration: InputDecoration(
                            hintText: 'Tanyakan pada KrakenX...',
                            hintStyle: TextStyle(
                              color: textMuted.withOpacity(0.5),
                              fontFamily: 'Rajdhani',
                              fontSize: 14,
                            ),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 12,
                            ),
                            prefixIcon: Icon(
                              Icons.edit,
                              color: textMuted.withOpacity(0.3),
                              size: 20,
                            ),
                            prefixIconConstraints: const BoxConstraints(
                              minWidth: 44,
                            ),
                          ),
                          onSubmitted: (text) => _sendMessage(text),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    
                    // Send Button with Gradient Glow
                    AnimatedBuilder(
                      animation: _pulseAnimation,
                      builder: (context, child) {
                        return AnimatedBuilder(
                          animation: _glowAnimation,
                          builder: (context, child) {
                            return Container(
                              width: 52,
                              height: 52,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: _isLoading
                                    ? LinearGradient(
                                        colors: [krakenRed.withOpacity(0.5), krakenPurple.withOpacity(0.5)],
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                      )
                                    : LinearGradient(
                                        colors: [krakenRed, krakenPurple],
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                        stops: const [0.0, 1.0],
                                      ),
                                boxShadow: _isLoading
                                    ? null
                                    : [
                                        BoxShadow(
                                          color: krakenRed.withOpacity(0.3 * _pulseAnimation.value),
                                          blurRadius: 20,
                                          spreadRadius: 4,
                                          offset: const Offset(0, 4),
                                        ),
                                        BoxShadow(
                                          color: krakenPurple.withOpacity(0.1 * _glowAnimation.value),
                                          blurRadius: 30,
                                          spreadRadius: 8,
                                          offset: const Offset(0, 0),
                                        ),
                                      ],
                              ),
                              child: Material(
                                color: Colors.transparent,
                                child: InkWell(
                                  onTap: _isLoading ? null : () => _sendMessage(_textController.text),
                                  borderRadius: BorderRadius.circular(26),
                                  child: Center(
                                    child: _isLoading
                                        ? const SizedBox(
                                            width: 24,
                                            height: 24,
                                            child: CircularProgressIndicator(
                                              strokeWidth: 2,
                                              color: Colors.white,
                                            ),
                                          )
                                        : const Icon(
                                            Icons.send,
                                            color: Colors.white,
                                            size: 24,
                                          ),
                                  ),
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}