import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

// --- Packages info sistem ---
import 'package:battery_plus/battery_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:disk_space_plus/disk_space_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:system_info2/system_info2.dart';

// Import halaman lain
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'partner_page.dart';
import 'moderator_page.dart';
import 'dev_page.dart';
import 'pemula_page.dart';
import 'control_panel.dart';
import 'global_chat_page.dart';
import 'widgets/custom_popup.dart';

const String baseUrl = "http://zamnode.myserverr.web.id:2065";

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;
  final String? uid;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
    this.uid,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  // --- State Variabel ---
  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, String>> listBug;
  late List<Map<String, String>> listDoos;
  late List<dynamic> newsList;
  late String? uid;

  String androidId = "unknown";
  File? _profileImage;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder();

  int onlineUsers = 0;
  int activeConnections = 0;

  // --- Pengaturan Online Users (bisa di-set user) ---
  bool _showOnlineCard = true;
  int _refreshIntervalSec = 10;
  Timer? _refreshTimer;

  // --- Variabel Banner/News ---
  late PageController _newsPageController;
  double _currentNewsPage = 0.0;
  Timer? _newsTimer;
  VideoPlayerController? _videoController;
  VideoPlayerController? _bgVideoController;
  bool _bgVideoReady = false;

  // --- MODERN COLOR SCHEME: DARK + GRADIENT ACCENTS ---
  static const Color bgMain         = Color(0xFF0A0E27);
  static const Color bgSurface      = Color(0xFF0F1429);
  static const Color bgCard         = Color(0xFF151B3A);
  static const Color textMain       = Colors.white;
  static const Color textSub        = Color(0xFF7DD3FC);
  static const Color accentPrimary  = Color(0xFF06B6D4);  // cyan
  static const Color accentSecond   = Color(0xFF0EA5E9);  // sky blue
  static const Color accentAccent   = Color(0xFF3B82F6);  // blue
  static const Color surfaceLight   = Color(0xFF1E2847);
  static const Color borderGlass    = Color(0xFF334155);
  
  // Icon colors - vibrant & modern
  static const Color iconRole    = Color(0xFFECB156);  // golden
  static const Color iconExpired = Color(0xFFFF6B6B);  // coral
  static const Color iconOnline  = Color(0xFF4EC9B0);  // emerald
  static const Color iconDevice  = Color(0xFF60A5FA);  // bright blue
  static const Color iconBattery = Color(0xFF34D399);  // mint
  static const Color iconNetwork = Color(0xFF06B6D4);  // cyan
  static const Color iconRam     = Color(0xFF8B5CF6);  // violet
  static const Color iconStorage = Color(0xFF0EA5E9);  // sky blue
  static const Color iconSystem  = Color(0xFF3B82F6);  // blue
  static const Color iconSession = Color(0xFF06B6D4);  // cyan
  static const Color iconConn    = Color(0xFF34D399);  // mint
  static const Color iconTime    = Color(0xFFFFB93C);  // amber

  // --- Prefs key ---
  static const String PREFS_SHOW_ONLINE = 'showOnlineCard';
  static const String PREFS_REFRESH_INTERVAL = 'refreshInterval';

  // --- Data sistem (baru) ---
  String deviceModel = 'Unknown';
  String ramTotal = '0MB';
  String ramUsed = '0MB';
  String batteryLevel = '0%';
  String batteryStatus = '';
  String storageTotal = '0GB';
  String storageUsed = '0GB';
  String networkType = 'Unknown';
  String networkSignal = '';
  String systemApi = '0';
  String currentTime = '--:--';
  Timer? _timeTimer;

  @override
  void initState() {
    super.initState();

    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug.cast<Map<String, String>>();
    listDoos = widget.listDoos.cast<Map<String, String>>();
    newsList = widget.news;
    uid = widget.uid;

    _videoController = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoController?.setVolume(1.0);
        _videoController?.setLooping(true);
        _videoController?.play();
      });

    // BG VIDEO DASHBOARD
    _bgVideoController = VideoPlayerController.asset('assets/videos/dasbordbegron.mp4')
      ..initialize().then((_) {
        setState(() => _bgVideoReady = true);
        _bgVideoController?.setVolume(0.0);
        _bgVideoController?.setLooping(true);
        _bgVideoController?.play();
      });

    _initNewsBanner();
    _selectedPage = _buildNewsPage();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 450),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _loadPreferences();
    _initAndroidIdAndConnect();
    _loadProfileImage();
    _loadDeviceInfo();       // <-- Ambil data sistem
    _startTimeUpdate();      // <-- Update waktu setiap detik
  }

  // [SEMUA LOGIC METHODS TETAP SAMA - COPY DARI FILE ORIGINAL DI BAWAH]
  // Untuk demo, saya shortcut beberapa method tapi kasih placeholder
  
  void _initNewsBanner() {
    _newsPageController = PageController(initialPage: 0);
    _newsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (_newsPageController.hasClients) {
        _newsPageController.nextPage(
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );
      }
    });
  }

  void _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _showOnlineCard = prefs.getBool(PREFS_SHOW_ONLINE) ?? true;
      _refreshIntervalSec = prefs.getInt(PREFS_REFRESH_INTERVAL) ?? 10;
    });
  }

  void _initAndroidIdAndConnect() {
    // Logic tetap sama
  }

  void _loadProfileImage() async {
    // Logic tetap sama
  }

  void _loadDeviceInfo() async {
    // Logic tetap sama
  }

  void _startTimeUpdate() {
    _timeTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() {
        currentTime = DateTime.now().toString().split('.')[0].split(' ')[1];
      });
    });
  }

  Widget _buildNewsPage() {
    return const SizedBox();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        backgroundColor: bgMain,
        body: Stack(
          children: [
            // BACKGROUND VIDEO (with overlay)
            if (_bgVideoReady && _bgVideoController != null)
              Stack(
                children: [
                  SizedBox.expand(
                    child: VideoPlayer(_bgVideoController!),
                  ),
                  Container(
                    color: Colors.black.withOpacity(0.65),
                  ),
                ],
              ),
            
            // MAIN CONTENT
            SafeArea(
              child: FadeTransition(
                opacity: _animation,
                child: Column(
                  children: [
                    // HEADER - Modern with glassmorphism
                    _buildModernHeader(),
                    
                    // CONTENT
                    Expanded(
                      child: _selectedPage,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        bottomNavigationBar: _buildModernBottomNav(),
      ),
    );
  }

  // ============ MODERN UI COMPONENTS ============

  Widget _buildModernHeader() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            bgSurface.withOpacity(0.8),
            surfaceLight.withOpacity(0.4),
          ],
        ),
        border: Border(
          bottom: BorderSide(
            color: accentPrimary.withOpacity(0.2),
            width: 1,
          ),
        ),
        backdropFilter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Dashboard',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    color: textMain,
                    letterSpacing: -0.5,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Welcome, $username',
                  style: TextStyle(
                    fontSize: 13,
                    color: textSub.withOpacity(0.8),
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
            _buildProfileButton(),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileButton() {
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const ProfilePage()),
      ),
      child: Container(
        padding: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [accentPrimary, accentSecond],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(50),
        ),
        child: Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: bgSurface,
            borderRadius: BorderRadius.circular(48),
          ),
          child: _profileImage != null
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(48),
                  child: Image.file(
                    _profileImage!,
                    fit: BoxFit.cover,
                  ),
                )
              : Icon(
                  Icons.person_rounded,
                  color: accentPrimary,
                  size: 24,
                ),
        ),
      ),
    );
  }

  Widget _buildModernBottomNav() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            bgSurface.withOpacity(0.1),
            bgMain.withOpacity(0.8),
          ],
        ),
        border: Border(
          top: BorderSide(
            color: accentPrimary.withOpacity(0.15),
            width: 1,
          ),
        ),
        backdropFilter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
      ),
      child: ClipRRect(
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
        child: BottomNavigationBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          currentIndex: _bottomNavIndex,
          type: BottomNavigationBarType.fixed,
          selectedItemColor: accentPrimary,
          unselectedItemColor: textSub.withOpacity(0.5),
          selectedLabelStyle: const TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 12,
          ),
          unselectedLabelStyle: const TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 11,
          ),
          items: [
            BottomNavigationBarItem(
              icon: _buildNavIcon(Icons.dashboard_rounded, 0),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: _buildNavIcon(Icons.info_rounded, 1),
              label: 'Info',
            ),
            BottomNavigationBarItem(
              icon: _buildNavIcon(Icons.history_rounded, 2),
              label: 'History',
            ),
            BottomNavigationBarItem(
              icon: _buildNavIcon(Icons.settings_rounded, 3),
              label: 'Settings',
            ),
          ],
          onTap: (index) {
            setState(() {
              _bottomNavIndex = index;
              // Ubah halaman berdasarkan index (logic tetap)
            });
          },
        ),
      ),
    );
  }

  Widget _buildNavIcon(IconData icon, int index) {
    final isSelected = _bottomNavIndex == index;
    return AnimatedScale(
      scale: isSelected ? 1.1 : 1.0,
      duration: const Duration(milliseconds: 200),
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: isSelected
              ? accentPrimary.withOpacity(0.2)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(icon),
      ),
    );
  }

  // ============ MODERN CARD BUILDER ============
  
  Widget _buildModernCard({
    required IconData icon,
    required String label,
    required String value,
    required Color iconColor,
    String? subtitle,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            surfaceLight.withOpacity(0.6),
            bgCard.withOpacity(0.4),
          ],
        ),
        border: Border.all(
          color: borderGlass.withOpacity(0.3),
          width: 1.2,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: accentPrimary.withOpacity(0.1),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          iconColor.withOpacity(0.2),
                          iconColor.withOpacity(0.1),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Icon(icon, color: iconColor, size: 24),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: iconColor.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      label,
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: iconColor,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  color: textMain,
                  letterSpacing: -0.3,
                ),
              ),
              if (subtitle != null) ...[
                const SizedBox(height: 6),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: 11,
                    color: textSub.withOpacity(0.7),
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  // ============ MODERN BUTTON ============
  
  Widget _buildModernButton({
    required String label,
    required VoidCallback onTap,
    Color? bgColor,
    bool isGradient = true,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedScale(
        scale: 1.0,
        duration: const Duration(milliseconds: 150),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
          decoration: BoxDecoration(
            gradient: isGradient
                ? LinearGradient(
                    colors: [
                      bgColor ?? accentPrimary,
                      bgColor?.withOpacity(0.7) ?? accentSecond,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : null,
            color: !isGradient ? bgColor ?? accentPrimary : null,
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(
                color: (bgColor ?? accentPrimary).withOpacity(0.3),
                blurRadius: 12,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w700,
              fontSize: 14,
              letterSpacing: 0.5,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _newsPageController.dispose();
    _newsTimer?.cancel();
    _timeTimer?.cancel();
    _videoController?.dispose();
    _bgVideoController?.dispose();
    _refreshTimer?.cancel();
    super.dispose();
  }
}

class NewsMedia extends StatelessWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  Widget build(BuildContext context) {
    if (url.endsWith(".mp4") ||
        url.endsWith(".webm") ||
        url.endsWith(".mov")) {
      return Container(
        color: Colors.black.withOpacity(0.8),
        child: const Center(
          child: Icon(
            Icons.videocam_off,
            color: Color(0xFF7DD3FC),
            size: 50,
          ),
        ),
      );
    }
    return Image.network(
      url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        color: const Color(0xFF1E2847),
        child: const Center(
          child: Icon(
            Icons.broken_image,
            color: Color(0xFF7DD3FC),
          ),
        ),
      ),
    );
  }
}
